#include"filter.hpp"
#include"cost_filter.hpp"
#define APPLIED 1
#define UNAPPLIED 0

const string INVALID_COMMAND_FORM="Bad Request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string MIN_PRC="min_price";
const string MAX_PRC="max_price";

Cost_filter::Cost_filter(): Filter(){
}

void Cost_filter :: apllying_min_or_max_price(vector<string>com,vector<Flight*>flights){
    if(stof(com[4])<0)
        throw(INVALID_COMMAND_FORM);
    for(int j=0;j<flights.size();j++){
        flights[j]->set_cost_ok(1);
    }
    if(com[3]==MIN_PRC){
        for(int i=0;i<flights.size();i++){
            if(flights[i]->get_cost()<stof(com[4])){
                flights[i]->set_cost_ok(UNAPPLIED);
            }
        }    
    }
    else if(com[3]==MAX_PRC){
        for(int i=0;i<flights.size();i++){
            if(flights[i]->get_cost()>stof(com[4]) ){
                flights[i]->set_cost_ok(UNAPPLIED);
            }
        }
    }
}
void Cost_filter :: apllying_min_and_max_price(vector<string>com,vector<Flight*>flights){
    if(stof(com[4])< 0 || stof(com[6])<stof(com[4]))
        throw(INVALID_COMMAND_FORM);
    for(int j=0;j<flights.size();j++){
        flights[j]->set_cost_ok(1);
    }
    for(int i=0;i<flights.size();i++){
        if(flights[i]->get_cost()< stof(com[4]) || flights[i]->get_cost()>stof(com[6])){
            flights[i]->set_cost_ok(UNAPPLIED);
        }
    }
}
void Cost_filter :: apllying_max_and_min_price(vector<string>com,vector<Flight*>flights){
    if(stof(com[6])< 0 || stof(com[4])<stof(com[6]))
        throw(INVALID_COMMAND_FORM);
    for(int j=0;j<flights.size();j++){
        flights[j]->set_cost_ok(1);
    }
    for(int i=0;i<flights.size();i++){
        if(flights[i]->get_cost()< stof(com[6]) || flights[i]->get_cost()>stof(com[4])){
            flights[i]->set_cost_ok(UNAPPLIED);
        }
    }    
}
void  Cost_filter ::apply_filter(vector<string>com,vector<Flight*>flights){
    if(com[3]!=MIN_PRC && com[3]!=MAX_PRC)
        return ;
    if(com.size()==7){
        if(com[3]==MIN_PRC && com[5]==MAX_PRC)
            apllying_min_and_max_price(com,flights);
        else if(com[3]==MAX_PRC && com[5]==MIN_PRC)
            apllying_max_and_min_price(com,flights);
        else 
            throw(INVALID_COMMAND_FORM);
    }
    else if(com.size()==5){
        apllying_min_or_max_price(com,flights);
    }
    else{
        throw(INVALID_COMMAND_FORM);
    }
}