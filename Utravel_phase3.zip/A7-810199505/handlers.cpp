#include"handlers.hpp"
#include"filter.hpp"
#include"origin_destination_filter.hpp"
#include"cost_filter.hpp"
#include"airline_filter.hpp"
#include"date_filter.hpp"
#include<sstream>
#include<fstream>

using namespace std;

const string QUANT="quantity";
const string CLASS="class";
const string TYPE="type";
const string DEP_DATE="departure_date";
const string MIN_TIME="min_departure_time";
const string MAX_TIME="max_departure_time";
const string MIN_PRC="min_price";
const string MAX_PRC="max_price";
const string AIRLINE ="airline";
const string ID="id";
const string AMOUNT="amount";
const string PASS="password";
const string UN="username";

Response* Signup_Handler::callback( Request *req ){
	Response *res = new Response;
	res->setHeader( "Content-Type" , "text/html" );
	std::ostringstream body;
	try{
		int id =utravel_ptr->Sign_Up(req->getQueryParam(UN),req->getQueryParam(PASS));
		utravel_ptr->delete_filters();
		res=Response ::redirect("/user_page");
		res->setSessionId(to_string(id));
	}
	catch(exception& ex){
		ifstream input1("bad_request.txt");
		string line1;
		while( input1 >> line1 )
			body << line1 << endl;		
		body<< "<head><h1>An error has ocuured!</h1></head>"
		<<"<br/>"<<"<p>Error message: "<< ex.what() <<"</p>" << "<a href = \"/\" style=' margin:auto; text-align:center; color: black;'>try again</a></html>";
		res->setBody( body.str());
	}
	return res;
}

Response * Login_Handler :: callback(Request * req){
	Response * res=new Response;
	res->setHeader("Content-Type" , "text/html" );
	ostringstream error;
	try{
		int id=utravel_ptr->login(req->getQueryParam(UN),req->getQueryParam(PASS));
		utravel_ptr->delete_filters();	
		res=Response ::redirect("/user_page");	
		res->setSessionId(to_string(id));		
	}
	catch(exception& ex){
		ifstream input1("bad_request.txt");
		string line1;
		while( input1 >> line1 )
			error << line1 << endl; 
		error<< "<head><h1>An error has ocuured!</h1></head>"
		<<"<br/>"<<"<p>Error message: "<< ex.what() <<"</p>" << "<a href = '/login_page' style=' margin:auto; text-align:center; color: black;'>try again</a></html>";
		res->setBody( error.str());
	}
	return res;
}

void construct_userpage_table(ostringstream & body){
	body<<
"<style>"<<endl<<
"table, th, td {"<<endl<<
"  border:1px solid black;"<<endl<<
"}"<<endl<<
"caption{"<<endl<<
"  font-size: 24px;"<<endl<<
"  color:white"<<endl<<
"}"<<endl<<
"</style>"<<endl<<
"<body>"<<endl<<
"<table style='width:100%'>"<<endl<<
"    <caption>Flights</caption>"<<endl<<
"    <tr>"<<endl<<
"        <th scope='col'>Id</th>"<<endl<<
"        <th scope='col'>Airline</th>"<<endl<<
"        <th scope='col'>Origin</th>"<<endl<<
"        <th scope='col'>Destination</th>"<<endl<<
"        <th scope='col'>Cost</th>"<<endl<<
"        <th scope='col'>About</th>"<<endl<<
"    </tr>"<<endl;
}

void construct_filter_forms(ostringstream & body){
	body<<
"        <form action='/origin_destination_filter' method='get'>"<<endl<<
"            <label for='from'>From:</label>"<<endl<<
"            <input name='origin' type='text' placeholder='Origin'/>"<<endl<<
"            <label for='to'>To:</label>"<<endl<<
"            <input name='destination' type='text' placeholder='Destination' />"<<endl<<
"            <button type='submit'> Filter Flights</button> <br/>"<<endl<<
"        </form>"<<endl<<
"        <form action='/airline_filter' method='get'>"<<endl<<
"            <label for='airline'>Airline:</label>"<<endl<<
"            <input name='airline' type='text' placeholder='Airline'/>"<<endl<<
"            <button type='submit'> Filter Flights</button> <br/>"<<endl<<
"        </form>"<<endl<<
"        <form action='/date_filter' method='get'>"<<endl<<
"            <label for='departure_date'>Departure Date:</label>"<<endl<<
"            <input name='departure_date' type='text' placeholder='departure date'/>"<<endl<<
"            <label for='min_departure_time'>min departure time:</label>"<<endl<<
"            <input name='min_departure_time' type='text' placeholder='min departure time'/>"<<endl<<
"            <label for='max_departure_time'>max departure time:</label>"<<endl<<
"            <input name='max_departure_time' type='text' placeholder='max departure time'/>"<<endl<<
"            <button type='submit'> Filter Flights</button> <br/>"<<endl<<                      
"        </form>"<<endl<<
"        <form action='/cost_filter' method='get'>"<<endl<<
"            <label for='min_price'>Min Price:</label>"<<endl<<
"            <input name='min_price' type='text' placeholder='Min Price'/>"<<endl<<
"            <label for='max_price'>Max Price:</label>"<<endl<<
"            <input name='max_price' type='text' placeholder='Max Price' />"<<endl<<
"            <button type='submit'> Filter Flights</button> <br/>"<<endl<<
"        </form>"<<endl<<
"	<a href='/delete_filters' style='color:white'>Delete Filters</a> "<<endl;
}

Response * UserPageHandler :: callback(Request * req){
	Response *res = new Response;
	res->setHeader( "Content-Type" , "text/html" );
	ostringstream body;
	int id=stoi(req->getSessionId());
	body<<
"<!DOCTYPE html>"<<endl<<
"<html>"<<endl<<
"<style>"<<endl<<
"body {"<<endl<<
"    background-image: url('user_back.jpg');"<<endl<<
"    background-size: cover;"<<endl<<
"    background-repeat: no-repeat;"<<endl<<
"}"<<endl<<
"h1 {"<<endl<<
"  color: white;"<<endl<<
"}"
"</style>"<<
"<h1>Welcome to your page</h1>"<<endl<<
"<body>"<<endl<<
"<p>Your wallet money value :"<<utravel_ptr->get_user(id)->get_wallet_money()<<"</p>"<<endl<<
"<form action='/charge_wallet'>"<<endl<<
"    <input name='amount' type='text' placeholder='Amount' />"<<endl<<
"    <input type='submit' value='Charge my wallet' />"<<endl<<
"</form><br><br>"<<endl;
	construct_filter_forms(body);	
	construct_userpage_table(body);
	body << utravel_ptr->Show_all_flights();
	body << "</table>"<<"<table>"<<""<<"<table style='width:100%'>"<<"<caption>Tickets</caption>"<<
	"<th scope='col'>Id</th>"<<"<th scope='col'> Flight Id</th>"<<"<th scope='col'>Quantity</th>"<<
	"<th scope='col'>Cost</th>"<<"<th scope='col'>About</th>"<<"</tr>";
	body<< utravel_ptr->get_user(id)->print_tickets();
	body<<
"	<a href='/' style='color:blue'>Logout</a> "<<endl;
	res->setBody( body.str() );
	return res;	
}

Response * Successful_charge :: callback(Request * req){
	Response *res = new Response;
	res->setHeader( "Content-Type" , "text/html" );
	int id=stoi(req->getSessionId());
	res->setSessionId(to_string(id));
	ostringstream body;	
	body<<
"<!DOCTYPE html>"<<endl<<
"<html>"<<endl<<
"   <style>"<<endl<<
"        body{"<<endl<<
"           background-color:  rgb(215, 218, 86);"<<endl<<
"        }"<<endl<<
"        p{"<<endl<<
"            font-size: 80px;"<<endl<<
"			  color: blue;"<<endl<<
"			  text-align: center;"
"			  align-items: center;"<<endl<<
"			  justify-content: center;"<<endl<<
"        }"<<endl<<
"   </style>"<<endl<<
"<body>"<<endl<<
"<p>Successfully done ! :)</p>"<<endl<<
"	<a href='/user_page' style=' margin:auto; text-align:center; color: blue;' >Go to Previous Page</a>"<<endl<<
"</body>"<<endl<<
"</html>"<<endl;
	res->setBody( body.str() );	
	return res;
}


Response * Charge_wallet_Handler :: callback(Request * req){
	Response *res = new Response;
	res->setHeader( "Content-Type" , "text/html" );
	int id=stoi(req->getSessionId());
	ostringstream body;
	try{
		utravel_ptr->get_user(id)->charge_wallet(stoi(req->getQueryParam(AMOUNT)));
		res=Response ::redirect("/succesfull_charge");
	}
	catch(exception& ex){
		ifstream input1("bad_request.txt");
		string line1;
		while( input1 >> line1 )
			body << line1 << endl;
		body<< "<head><h1>An error has ocuured!</h1></head>"
		<<"<br/>"<<"<p>Error message: "<< ex.what() <<"</p>" << "<a href = '/user_page' style=' margin:auto; text-align:center; color: black;'>try again</a></html>";
		res->setBody( body.str());
	}
	return res;
}

Response * Show_Flight_info_Handler :: callback(Request * req){
	Response *res = new Response;
	res->setHeader( "Content-Type" , "text/html" );
	ifstream input1("flight_info_page_part1.txt");
	ostringstream body;
	string line1;
	while( input1 >> line1 )
		body << line1 << endl;
	string id=req->getQueryParam(ID);
	body << utravel_ptr->Show_this_flight(stoi(id));
	ifstream input("Flight_info_page.txt");
	string line;
	while( input >> line )
		body << line << endl;
	body << 
"			<input type='hidden' name='id' id='hiddenField' value='"<<id<<"'>"<<endl<<
"            <button type='submit'> Buy </button>"<<endl<<
"	<a href='/user_page' style=' margin:auto; text-align:center; color: blue;'>Go to Previous Page</a>"<<endl<<
"    <form>"<<endl;
	res->setBody(body.str());
	return res;
}


Response * Show_Ticket_info_Handler:: callback(Request * req){
	Response *res = new Response;
	res->setHeader( "Content-Type" , "text/html" );
	ostringstream body;
	int user_id=stoi(req->getSessionId());
	ifstream input("Ticket_info_page.txt");
	string line;
	while( input >> line )
		body << line << endl;

	string id=req->getQueryParam(ID);
	body << utravel_ptr->get_user(user_id)->print_this_ticket(stoi(id))<<"</br>";
	body<<
"	<a href='/cancel_tick?id="<<id<<"' style='color: black'>"<<"Cancel ticket</a>"<<"</br>"<<"</br>"<<endl<<
"	<a href='/user_page' style='color: black' >Go to Previous Page</a>"<<endl;
	res->setBody(body.str());
	return res;
}

Response * Buy_Handler :: callback(Request * req){
	Response *res = new Response;
	res->setHeader( "Content-Type" , "text/html" );
	std::ostringstream body;
	int user_id=stoi(req->getSessionId());
	try{
		utravel_ptr->buy(req->getQueryParam(ID),req->getQueryParam(QUANT),req->getQueryParam(CLASS),req->getQueryParam(TYPE));
		res=Response ::redirect("/succesfull_charge");
	}
	catch(exception& ex){
		ifstream input1("bad_request.txt");
		string line1;
		while( input1 >> line1 )
			body << line1 << endl;
		body<< "<head><h1>An error has ocuured!</h1></head>"
		<<"<br/>"<<"<p>Error message: "<< ex.what() <<"</p>" <<"<a href='/full_info?id="<< req->getQueryParam(ID) <<"'style=' margin:auto; text-align:center; color: black;'>"<<" try again</a></html>";
		res->setBody( body.str());
	}	
	return res;
}

Response * Cancel_Handler :: callback(Request * req){
	Response *res = new Response;
	res->setHeader( "Content-Type" , "text/html" );
	std::ostringstream body;
	int user_id=stoi(req->getSessionId());
	try{
	utravel_ptr->get_user(user_id)->cancel_a_ticket(stoi(req->getQueryParam(ID)));
	res=Response ::redirect("/succesfull_charge");
	}
	catch(exception & ex){
		ifstream input1("bad_request.txt");
		string line1;
		while( input1 >> line1 )
			body << line1 << endl;
		body<< "<head><h1>An error has ocuured!</h1></head>"
		<<"<br/>"<<"<p>Error message: "<< ex.what() <<"</p>" << "<a href ='/tick_full_info"<<"?id="<<req->getQueryParam(ID)<<"'style=' margin:auto; text-align:center; color: black;'>"<<"try again</a></html>";
		res->setBody( body.str());		
	}
	return res;
} 

Response *Logout_Handler::callback(Request *req){
	Response *res = new Response;
	res->setSessionId("");
	res = Response::redirect("/");
	return res;
}

Response * Airline_Filter_Handler :: callback(Request * req){
	Response *res = new Response;
	res->setHeader( "Content-Type" , "text/html" );
	std::ostringstream body;
	try{
		Airline_filter * our_filter=new Airline_filter();
		our_filter->apply_filter(req->getQueryParam(AIRLINE),utravel_ptr->get_flights());
		res=Response ::redirect("/succesfull_charge");		
	}
	catch(exception& ex){
		ifstream input1("bad_request.txt");
		string line1;
		while( input1 >> line1 )
			body << line1 << endl;		
		body<< "<head><h1>An error has ocuured!</h1></head>"
		<<"<br/>"<<"<p>Error message: "<< ex.what() <<"</p>" << "<a href = '/user_page' style=' margin:auto; text-align:center; color: black;'>try again</a></html>";
		res->setBody( body.str());
	}
	return res;
}

Response * OD_Filter_Handler :: callback(Request * req){
	Response *res = new Response;
	res->setHeader( "Content-Type" , "text/html" );
	std::ostringstream body;
	try{
		origin_destination_filter * our_filter=new origin_destination_filter();
		our_filter->apply_filter(req->getQueryParam("origin"),req->getQueryParam("destination"),utravel_ptr->get_flights());
		res=Response ::redirect("/succesfull_charge");
	}
	catch(exception& ex){
		ifstream input1("bad_request.txt");
		string line1;
		while( input1 >> line1 )
			body << line1 << endl;		 
		body<< "<head><h1>An error has ocuured!</h1></head>"
		<<"<br/>"<<"<p>Error message: "<< ex.what() <<"</p>" << "<a href = '/user_page' style=' margin:auto; text-align:center; color: black;'>try again</a></html>";
		res->setBody( body.str());
	}
	return res;
}

Response * Cost_Filter_Handler :: callback(Request * req){
	Response *res = new Response;
	res->setHeader( "Content-Type" , "text/html" );
	std::ostringstream body;
	try{
		Cost_filter * our_filter=new Cost_filter();
		our_filter->apply_filter(req->getQueryParam(MIN_PRC),req->getQueryParam(MAX_PRC),utravel_ptr->get_flights());	
		res=Response ::redirect("/succesfull_charge");		
	}
	catch(exception& ex){
		ifstream input1("bad_request.txt");
		string line1;
		while( input1 >> line1 )
			body << line1 << endl;		
		body<< "<head><h1>An error has ocuured!</h1></head>"
		<<"<br/>"<<"<p>Error message: "<< ex.what() <<"</p>" << "<a href = '/user_page' style=' margin:auto; text-align:center; color: black;'>try again</a></html>";
		res->setBody( body.str());
	}
	return res;
}

Response * Date_Filter_Handler :: callback(Request * req){
	Response *res = new Response;
	res->setHeader( "Content-Type" , "text/html" );
	std::ostringstream body;
	try{
		Date_filter * our_filter=new Date_filter();
		our_filter->apply_filter(req->getQueryParam(DEP_DATE),req->getQueryParam(MIN_TIME),req->getQueryParam(MAX_TIME),utravel_ptr->get_flights());
		res=Response ::redirect("/succesfull_charge");		
	}
	catch(exception& ex){
		ifstream input1("bad_request.txt");
		string line1;
		while( input1 >> line1 )
			body << line1 << endl;		
		body<< "<head><h1>An error has ocuured!</h1></head>"
		<<"<br/>"<<"<p>Error message: "<< ex.what() <<"</p>" << "<a href = '/user_page' style=' margin:auto; text-align:center; color: black;'>try again</a></html>";
		res->setBody( body.str());
	}
	return res;
}

Response * Delete_Filter_Handler :: callback(Request *req){
	Response *res = new Response;
	res->setHeader( "Content-Type" , "text/html" );
	std::ostringstream body;
	utravel_ptr->delete_filters();
	res=Response ::redirect("/succesfull_charge");	
	return res;
}