#include"filter.hpp"
#include"date_filter.hpp"
#include<string>
#include<sstream>
#include"exception.hpp"
#define APPLIED 1
#define UNAPPLIED 0

const string INVALID_COMMAND_FORM="Bad Request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string DEP_DATE="departure_date";
const string MIN_TIME="min_departure_time";
const string MAX_TIME="max_departure_time";

int convert_time_to_int(string time ){
    string temp_str;
    vector<int>temp_vec;
    stringstream X(time);
    while (getline(X, temp_str, ':')) {
        temp_vec.push_back(stoi(temp_str));
    }
    return temp_vec[0]*60+temp_vec[1];

}

Date_filter:: Date_filter(){
    
}
void Date_filter :: apply_dep_date(string departure_date,vector<Flight*>flights){
    for(int j=0;j<flights.size();j++){
        flights[j]->set_date_ok(APPLIED);
    }
    for(int i=0;i<flights.size();i++){
        if(flights[i]->get_departure_date()!=departure_date ){            
            flights[i]->set_date_ok(UNAPPLIED);
        }
    }
}
void Date_filter :: apply_min_time(string departure_date,string min_departure_time,vector<Flight*>flights){
    int min_time=convert_time_to_int(min_departure_time);
    if(min_time<0 || min_time>1440)
        throw Bad_request();
    for(int j=0;j<flights.size();j++)
        flights[j]->set_date_ok(1);
    for(int i=0;i<flights.size();i++){
        int dep_time=convert_time_to_int(flights[i]->get_departure_time());
        if(flights[i]->get_departure_date()!=departure_date || dep_time<min_time )           
            flights[i]->set_date_ok(UNAPPLIED);
    }
}

void Date_filter :: apply_max_time(string departure_date,string max_departure_time,vector<Flight*>flights){
    int max_time=convert_time_to_int(max_departure_time);
    if(max_time<0 || max_time>1440)
        throw Bad_request();
    for(int j=0;j<flights.size();j++)
        flights[j]->set_date_ok(1);
    for(int i=0;i<flights.size();i++){
        int dep_time=convert_time_to_int(flights[i]->get_departure_time());
        if(flights[i]->get_departure_date()!=departure_date || dep_time>max_time )           
            flights[i]->set_date_ok(UNAPPLIED);
    }
}
void Date_filter:: apply_complete_time_filter(string departure_date,string min_departure_time,string max_departure_time,vector<Flight*>flights){
    int min_time=convert_time_to_int(min_departure_time);
    int max_time=convert_time_to_int(max_departure_time);
    if(min_time<0 || max_time>1440 || max_time<min_time)
        throw Bad_request(); 
    for(int j=0;j<flights.size();j++){
        flights[j]->set_date_ok(1);
    }          
    for(int i=0;i<flights.size();i++){
        int dep_time=convert_time_to_int(flights[i]->get_departure_time());
        if(flights[i]->get_departure_date()!=departure_date || dep_time<min_time || dep_time>max_time){            
            flights[i]->set_date_ok(UNAPPLIED);
        }
    }   
}
void Date_filter ::apply_filter(string departure_date,string min_departure_time,string max_departure_time,vector<Flight*>flights){
    if(departure_date!="" && min_departure_time=="" && max_departure_time=="")
        apply_dep_date(departure_date,flights);
    else if(departure_date!="" && min_departure_time!="" && max_departure_time=="")
        apply_min_time(departure_date,min_departure_time,flights);
    else if(departure_date!="" && min_departure_time=="" && max_departure_time!="")
        apply_max_time(departure_date,max_departure_time,flights); 
    else if(departure_date!="" && min_departure_time!="" && max_departure_time!="") 
        apply_complete_time_filter(departure_date,min_departure_time,max_departure_time,flights);
    else 
        throw Bad_request();
}