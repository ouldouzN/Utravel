#include"filter.hpp"
#include"airline_filter.hpp"
#define APPLIED 1
#define UNAPPLIED 0

const string INVALID_COMMAND_FORM="Bad Request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string AIRLINE ="airline";
Airline_filter :: Airline_filter (): Filter(){
}

void Airline_filter :: apply_filter(vector<string>com,vector<Flight*>flights){
    if(com[3]==AIRLINE){
        if(com.size()==5){
            for(int j=0;j<flights.size();j++){
                flights[j]->set_airline_ok(1);
            }
            for(int i=0;i<flights.size();i++){
                if(flights[i]->get_airline()!=com[4]){
                    flights[i]->set_airline_ok(0);
                }
            }
        }
        else
            throw(INVALID_COMMAND_FORM);
    }
    else{
        return ;
    }
}