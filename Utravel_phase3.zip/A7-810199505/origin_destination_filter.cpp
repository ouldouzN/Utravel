#include"filter.hpp"
#include"origin_destination_filter.hpp"
#include"cost_filter.hpp"
#include"airline_filter.hpp"
#include"date_filter.hpp"

#define APPLIED 1
#define UNAPPLIED 0

const string INVALID_COMMAND_FORM="Bad Request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string FROM="from";
const string TO="to";

origin_destination_filter ::origin_destination_filter(){
}

void origin_destination_filter ::apply_filter(string origin,string destination,vector<Flight*>flights){
    if(origin=="" || destination=="")
        throw Bad_request();
    for(int j=0;j<flights.size();j++)
        flights[j]->set_origin_ok(APPLIED);
    for(int i=0;i<flights.size();i++){
        if(flights[i]->get_origin()!=origin || flights[i]->get_destination()!=destination)
            flights[i]->set_origin_ok(UNAPPLIED);
    }
}