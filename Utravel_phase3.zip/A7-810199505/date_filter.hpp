#ifndef _DATE_HPP_
#define _DATE_HPP_

#include<iostream>
#include<string>

using namespace std;

class Date_filter {
    public:
        Date_filter();
        void apply_filter(string departure_date,string min_departure_time,string max_departure_time,vector<Flight*>flights);
        void apply_dep_date(string departure_date,vector<Flight*>flights);
        void apply_min_time(string departure_date,string min_departure_time,vector<Flight*>flights);
        void apply_max_time(string departure_date,string max_departure_time,vector<Flight*>flights);
        void apply_complete_time_filter(string departure_date,string min_departure_time,string max_departure_time,vector<Flight*>flights);
        void divide_according_command(vector<string>com,vector<Flight*>flights);
    private:
        string deparure_date;
        int min_time;
        int max_time;

};

#endif