#ifndef _TICK_HPP_
#define _TICK_HPP_
#include"flight.hpp"


class Ticket{
public:
    Ticket(int id,Flight* tick_flight_,int quantity,string tick_class,string tick_type);
    float get_cost();
    Flight * get_flight();
    string get_class();
    int get_quantity();
    void set_id(int tick_id);
    int get_id();
    string print();
    string get_type();
    string print_full_info();
private:
    Flight *tick_flight;
    int quantity;
    string ticket_class;
    string ticket_type;
    int id;
    float cost;
};

#endif