#include"Commands.hpp"
#include"Utravel.hpp"
#include "server/server.hpp"
#include"handlers.hpp"

Command :: Command(vector<vector<string>>splitted_flights){
    my_utravel=new Utravel(splitted_flights);
}

void Command :: Run(){
    Server server(8080);
    server.get("/signup_back.jpg",new ShowImage("signup_back.jpg"));
    server.get("/user_back.jpg",new ShowImage("user_back2.jpg"));
    server.get("/flight_info_back.jpg",new ShowImage("flight_back.jpg"));
    server.get("/tick_back.jpg",new ShowImage("ticket_back.jpg"));
    server.get("/success_back.jpg",new ShowImage("success_back2.png"));
    server.get("/",new ShowPage("signUp.html"));
    server.get("/signup",new Signup_Handler(my_utravel));
    server.get( "/user_page" , new UserPageHandler(my_utravel));
    server.get("/login_page",new ShowPage("login.html"));
    server.get("/charge_wallet",new Charge_wallet_Handler(my_utravel));
    server.get("/charge_wallet?",new Charge_wallet_Handler(my_utravel));
    server.get("/login",new Login_Handler(my_utravel));
    server.get("/logout",new Logout_Handler(my_utravel));
    server.get("/full_info",new Show_Flight_info_Handler(my_utravel));
    server.get("/buy",new Buy_Handler(my_utravel));
    server.get("/tick_full_info",new Show_Ticket_info_Handler(my_utravel)); 
    server.get("/succesfull_charge",new Successful_charge(my_utravel));   
    server.get("/cancel_tick",new Cancel_Handler(my_utravel));
    server.get("/airline_filter",new Airline_Filter_Handler(my_utravel));
    server.get("/origin_destination_filter",new OD_Filter_Handler(my_utravel));
    server.get("/cost_filter",new Cost_Filter_Handler(my_utravel));
    server.get("/date_filter",new Date_Filter_Handler(my_utravel));
    server.get("/delete_filters",new Delete_Filter_Handler(my_utravel));    
    server.run();
       
}
Utravel * Command:: get_Utravel_ptr(){
    return my_utravel;
}
