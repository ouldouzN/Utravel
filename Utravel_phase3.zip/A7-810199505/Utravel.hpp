#ifndef _UT_HPP_
#define _UT_HPP_

#include"flight.hpp"
#include"user.hpp"
#include"ticket.hpp"
#include<vector>
#include<string>

using namespace std;

class User;

class Utravel{
    public:
        Utravel(vector<vector<string>>splitted_flights);
        int Sign_Up(string username,string password);
        int  find_user(string username);
        int login(string username,string password);
        void Add_flight_table_structure(ostringstream &body);
        void Add_flight_info_to_tabl(ostringstream &body,int id);
        string Show_this_flight(int id);
        string Show_all_flights();
        void  buy(string id,string quantity,string flight_class ,string flight_type);
        bool  username_existence(string username);
        void delete_filters();
        User * get_current_user();
        User * get_user(int id);
        vector<Flight *>get_flights();

    private:
        vector<Flight*>flights;
        vector< User*> users;
        int signed_status;
        User * current_user;
        int tickets_num=0;

};
#endif