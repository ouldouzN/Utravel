#ifndef _CNT_FLT_
#define _CNT_FLT_
#include"flight.hpp"

class Connecting_Flight{
    public:
        Connecting_Flight(Flight * first,Flight *second,int duration);
        void print();
        float get_cost();
        Flight * get_first_flight();
        Flight * get_second_flight();
    private:
        Flight * first_flight;
        Flight * second_flight;
        float total_cost;
        int connection_duration;
};

#endif