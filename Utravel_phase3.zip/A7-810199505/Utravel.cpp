#include"Utravel.hpp"
#include"exception.hpp"
#include "server/server.hpp"
#include<string>
#include<iostream>
#include<sstream>

#define APPLIED 1
#define ERR -1

using namespace std;

const string INVALID_COMMAND_FORM="Bad Request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";

Utravel :: Utravel(vector<vector<string>>utravel_flights){
    for(int i=0;i<utravel_flights.size();i++){
        Flight * temp=new Flight(utravel_flights[i],i+1);
        flights.push_back(temp);
    }
}
bool Utravel:: username_existence(string username){
    for(int i=0;i<users.size();i++){
        if(users[i]->get_username()==username)
            return true;
    }
    return false;

}
int Utravel :: Sign_Up(string username,string password){
    if(username_existence(username)){
        throw Bad_request();
    }
    else{
        User * new_user=new User(username,password);
        users.push_back(new_user);
        current_user=new_user;
        signed_status=1;
        return (users.size()-1);
    }     
}
int Utravel:: find_user(string username){
    for(int i=0;i<users.size();i++){
        if(users[i]->get_username()==username)
            return i;
    }
    return ERR;

}

int Utravel:: login(string username,string password){
    if(!username_existence(username)){
        throw Bad_request();
    }
    else{
        int user_index=find_user(username);
        if(users[user_index]->get_password()==password){
            current_user=users[user_index];
            signed_status=1;
            return user_index;
        }
        else
            throw Bad_request();
    }      
}

User * Utravel :: get_user(int id){
    return users[id];
}

void Utravel:: Add_flight_table_structure(ostringstream &body){
    body<< "<style>"<<
"            table, th, td {"<<endl<<
"                border:1px solid black;"<<endl<<
"            }"<<endl<<
"            caption{"<<endl<<
"               font-size: 24px;"<<endl<<
"            }"<<endl<<
"            </style>"<<endl<<
"            <table style='width:100%'>"<<endl<<
"                <caption>Flight Info</caption>"<<endl<<
"                <tr>"<<endl<<
"                   <th scope='col'>Id</th>"<<endl<<
"                   <th scope='col'>Airline</th>"<<endl<<
"                   <th scope='col'>Origin</th>"<<endl<<
"                   <th scope='col'>Destination</th>"<<endl<<
"                   <th scope='col'>Departure Date</th>"<<endl<<
"                   <th scope='col'>Departure Time</th>"<<endl<<
"                   <th scope='col'>Arrival Date</th>"<<endl<<
"                   <th scope='col'>Arrival Time</th>"<<endl<<
"                   <th scope='col'>Available seats</th>"<<endl<<
"                   <th scope='col'>Cost</th>"<<endl<<
"                 </tr>"<<endl;
}
void Utravel:: Add_flight_info_to_tabl(ostringstream &body,int id){
    body<<
"                <tr>"<<endl<<
"                   <td>"<<id<<"</th>"<<endl<<
"                   <td>"<<flights[id-1]->get_airline()<<"</td>"<<endl<<
"                   <td>"<<flights[id-1]->get_origin()<<"</td>"<<endl<<
"                   <td>"<<flights[id-1]->get_destination()<<"</td>"<<endl<<
"                   <td>"<<flights[id-1]->get_departure_date()<<"</td>"<<endl<<
"                   <td>"<<flights[id-1]->get_departure_time()<<"</td>"<<endl<<
"                   <td>"<<flights[id-1]->get_arrival_date()<<"</td>"<<endl<<
"                   <td>"<<flights[id-1]->get_arrival_time()<<"</td>"<<endl<<
"                   <td>"<<flights[id-1]->get_seats()<<"</td>"<<endl<<
"                   <td>"<<flights[id-1]->get_cost()<<"</td>"<<endl<<
"                </tr>"<<endl<<
"                </table>"<<"<br>"<<endl;
}

string Utravel::Show_this_flight(int id){
    Response *res = new Response;
    ostringstream body;
    Add_flight_table_structure(body);
    Add_flight_info_to_tabl(body,id);
    body<<"</body>"<<endl<<"</html>"<<endl;
    return body.str();
}

string  Utravel::Show_all_flights(){
    ostringstream body;
    body<<"<tr>";
    for(int i=0;i<flights.size();i++){
        if(flights[i]->get_seats()!=0 && flights[i]->get_airline_ok()==1 &&
        flights[i]->get_cost_ok()==1 && flights[i]->get_date_ok()==1 &&
        flights[i]->get_origin_ok()==1)
            body<<flights[i]->print_flight_info();
    }
    body<<"</tr>";
    return body.str();
}
User * Utravel:: get_current_user(){
    return current_user;
}

void Utravel :: delete_filters(){
    for(int i=0;i<flights.size();i++){
        flights[i]->set_airline_ok(APPLIED);
        flights[i]->set_cost_ok(APPLIED);
        flights[i]->set_origin_ok(APPLIED);
        flights[i]->set_date_ok(APPLIED);
    }
}
void  Utravel :: buy(string id,string quantity,string flight_class ,string flight_type){
    if(flight_class=="economy"){
        if(stoi(quantity) >flights[stoi(id)-1]->get_economy_seats() || stoi(quantity)<0)
            throw Bad_request();
        else{
            if(current_user->get_wallet_money()< flights[stoi(id)-1]->get_cost()*stoi(quantity)){
                throw Bad_request();
            }
            else{
                current_user->buy_ticket(tickets_num,flights[stoi(id)-1],stoi(quantity),flight_class,flight_type);
                tickets_num+=1;
            }
        }
    }
    else{
        if(stoi(quantity)>flights[stoi(id)-1]->get_business_seats() || stoi(quantity)<0 )
            throw Bad_request();
        else{
            if(current_user->get_wallet_money()< flights[stoi(id)-1]->get_cost()*stoi(quantity)*2.5){
                throw Bad_request();
            }
            else{
                current_user->buy_ticket(tickets_num,flights[stoi(id)-1],stoi(quantity),flight_class,flight_type);
                tickets_num+=1;
            }
        }        
    }
}
vector<Flight *> Utravel:: get_flights(){
    return flights;
}