#ifndef _FILTER_HPP_
#define _FILTER_HPP_
#include<vector>
#include<string>
#include"flight.hpp"


using namespace std;

class Filter{
    public:
        Filter();
        virtual void apply_filter(vector<string>com,vector<Flight*>flights)=0;

    protected:
        int applied_state;
        
};

#endif