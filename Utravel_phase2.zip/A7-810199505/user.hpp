#ifndef _USER_HPP_
#define _USER_HPP_
#include<string>
#include"vector"
#include"ticket.hpp"
#include"Utravel.hpp"


using namespace std;

class User{
    public:
        User(string name,string pass);
        ~User();
        string get_username();
        void charge_wallet(float amount);
        void buy_ticket(vector<string>command,vector<Flight*>flights,int tickets_num,int flight_index,int quantity_index,int class_index,int type_index);
        void print_tickets();
        void print_this_ticket(int id);
        Ticket * cancel_a_ticket(int id);
        string get_password();
        void set_id(int id);
        void calculate_left_money(Ticket * this_tick);
        void change_seats(Ticket * this_tick);
        int find_ticket(int i);
        Ticket * get_ticket(int id);

    private:
        float wallet_money;
        vector<Ticket *>tickets;
        string username;
        string password;
        vector<int>ticket_status;
};

#endif