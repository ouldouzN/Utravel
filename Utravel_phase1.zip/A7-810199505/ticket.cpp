#include"ticket.hpp"
#include<iostream>

const string INVALID_COMMAND_FORM="Bad request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string BUSINESS="business";
const string ECO="economy";
const string REF="refundable";
const string NON_REF="nonrefundable";


Ticket :: Ticket(vector<string>command,vector<Flight*>flights,int flight_index,int quantity_index,int class_index,int type_index){
    float zarib=1;
    if(stoi(command[flight_index])>flights.size())
        throw(NON_ACCEPTABLE_COMMAND);
    if(command[class_index]!=BUSINESS && command[class_index]!=ECO)
        throw(INVALID_COMMAND_FORM);
    if(command[type_index]!=REF && command[type_index]!=NON_REF)
        throw(INVALID_COMMAND_FORM);
    tick_flight=flights[stoi(command[flight_index])-1];
    quantity=stoi(command[quantity_index]);
    ticket_class=command[class_index];
    ticket_type=command[type_index];
    if(ticket_class==BUSINESS)
        zarib=2.5;
    cost=zarib * quantity * (tick_flight->get_cost());   
}
Flight * Ticket:: get_flight(){
    return tick_flight;
}
float Ticket:: get_cost(){
    return cost;
}
string Ticket:: get_class(){
    return ticket_class;
}
int Ticket :: get_quantity(){
    return quantity;
}
void Ticket :: set_id(int tick_id){
    id=tick_id;
}
int Ticket :: get_id(){
    return id;
}
void Ticket :: print(){
    cout<<id<<" "<<(tick_flight->get_id())<<" "<<tick_flight->get_airline()<<" "<<quantity<<" "<<tick_flight->get_origin()<<
    " "<<tick_flight->get_destination()<<" "<<tick_flight->get_departure_date()<<" "<<
    tick_flight->get_departure_time()<<" "<<tick_flight->get_arrival_date()<<" "<<
    tick_flight->get_arrival_time()<<" ";
    cout<<ticket_class<<" "<<ticket_type<<" "<<cost<<endl;
}
string Ticket :: get_type(){
    return ticket_type;
}