#ifndef _AIRLINE_HPP_
#define _AIRLINE_HPP_

#include<iostream>
#include<string>

using namespace std;

class Airline_filter : public Filter{
    public:
        Airline_filter();
        virtual void apply_filter(vector<string>com,vector<Flight*>flights);
        
    private:
        string airline;
};

#endif