#ifndef _FLIGHT_HPP_
#define _FLIGHT_HPP_
#include<string>
#include<vector>
using namespace std;
class Flight{
    public:
        Flight(vector<string>flight_info,int flight_id);
        int get_economy_seats();
        int get_business_seats();
        int get_seats();
        void print_flight_info();
        string get_airline();
        string get_origin();
        string get_destination();
        string get_departure_date();
        string get_arrival_date();
        string get_departure_time();
        string get_arrival_time();
        float get_cost();
        int get_id();
        string get_kind();
        void change_seat_num(int num);
        void change_id(int new_id);
        void set_origin_ok(int val);
        void set_cost_ok(int val);
        void set_airline_ok(int val);
        void set_date_ok(int val);
        int get_origin_ok();
        int get_cost_ok();
        int get_airline_ok();
        int get_date_ok();
        void change_economy_seat_num(int num);
        void change_business_seat_num(int num);

    private:
        string airline;
        string origin;
        string destination;
        string departure_date;
        string arrival_date;
        string departure_time;
        string arrival_time;
        int economy_seats;
        int business_seats;
        float cost;
        int id;
        string kind;
        int origin_destination_ok;
        int cost_ok;
        int date_ok;
        int airline_ok;

};

#endif