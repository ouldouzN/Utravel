#include "server/server.hpp"
#include <cstdlib> // for rand and srand
#include <ctime>   // for time
#include <iostream>
#include"Commands.hpp"

class Signup_Handler:public RequestHandler {
public:
	Signup_Handler( Utravel * my_utravel){utravel_ptr=my_utravel;}
	Response *callback(Request * req);
private:
	Utravel * utravel_ptr;
};

class Login_Handler:public RequestHandler {
public:
	Login_Handler( Utravel * my_utravel){utravel_ptr=my_utravel;}
	Response *callback(Request * req);
private:
	Utravel * utravel_ptr;
};

class UserPageHandler : public RequestHandler{
	public:
		UserPageHandler( Utravel * my_utravel){utravel_ptr=my_utravel;}
		Response *callback(Request * req);
	private:
		Utravel * utravel_ptr;
};
class Wallet_Handler : public RequestHandler{
	public:
		Wallet_Handler( Utravel * my_utravel){utravel_ptr=my_utravel;}
		Response *callback(Request * req);

	private:
		Utravel * utravel_ptr;
};

class Show_Flight_info_Handler : public RequestHandler{
	public:
		Show_Flight_info_Handler( Utravel * my_utravel){utravel_ptr=my_utravel;}
		Response *callback(Request * req);

	private:
		Utravel * utravel_ptr;
};

class Show_Ticket_info_Handler : public RequestHandler{
	public:
		Show_Ticket_info_Handler( Utravel * my_utravel){utravel_ptr=my_utravel;}
		Response *callback(Request * req);

	private:
		Utravel * utravel_ptr;	
};

class Buy_Handler : public RequestHandler{
	public:
		Buy_Handler( Utravel * my_utravel){utravel_ptr=my_utravel;}
		Response *callback(Request * req);

	private:
		Utravel * utravel_ptr;
};

class Cancel_Handler : public RequestHandler {
	public:
		Cancel_Handler( Utravel * my_utravel){utravel_ptr=my_utravel;}
		Response *callback(Request * req);

	private:
		Utravel * utravel_ptr;
};

class Charge_wallet_Handler : public RequestHandler{
	public:
		Charge_wallet_Handler( Utravel * my_utravel){utravel_ptr=my_utravel;}
		Response *callback(Request * req);

	private:
		Utravel * utravel_ptr;
};

class Successful_charge : public RequestHandler{
	public:
		Successful_charge( Utravel * my_utravel){utravel_ptr=my_utravel;}
		Response *callback(Request * req);

	private:
		Utravel * utravel_ptr;
};

class Logout_Handler : public RequestHandler {
public:
	Logout_Handler( Utravel * my_utravel){utravel_ptr=my_utravel;};
	Response *callback(Request * req);
private:
	Utravel * utravel_ptr;
};

class Airline_Filter_Handler : public RequestHandler{
public:
	Airline_Filter_Handler( Utravel * my_utravel){ utravel_ptr=my_utravel;};
	Response *callback(Request * req);
private:
	Utravel * utravel_ptr;	
};

class OD_Filter_Handler : public RequestHandler{
public:
	OD_Filter_Handler( Utravel * my_utravel){ utravel_ptr=my_utravel;};
	Response *callback(Request * req);
private:
	Utravel * utravel_ptr;	
};

class Cost_Filter_Handler : public RequestHandler{
public:
	Cost_Filter_Handler( Utravel * my_utravel){ utravel_ptr=my_utravel;};
	Response *callback(Request * req);
private:
	Utravel * utravel_ptr;	
};

class Date_Filter_Handler : public RequestHandler{
public:
	Date_Filter_Handler( Utravel * my_utravel){ utravel_ptr=my_utravel;};
	Response *callback(Request * req);
private:
	Utravel * utravel_ptr;	
};

class Delete_Filter_Handler :public RequestHandler{
public:
	Delete_Filter_Handler( Utravel * my_utravel){ utravel_ptr=my_utravel;};
	Response *callback(Request * req);
private:
	Utravel * utravel_ptr;		
};