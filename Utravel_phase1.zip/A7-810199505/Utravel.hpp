#ifndef _UT_HPP_
#define _UT_HPP_
#include"flight.hpp"
#include"user.hpp"
#include"filter.hpp"
#include"origin_destination_filter.hpp"
#include"cost_filter.hpp"
#include"airline_filter.hpp"
#include"date_filter.hpp"
#include"ticket.hpp"
#include<vector>
#include<string>

using namespace std;

class User;

class Utravel{
    public:
        Utravel(vector<vector<string>>utravel_flights,vector<vector<string>>splitted_commands);
        void Sign_Up(vector<string>command);
        void Sign_Up_second_step(vector<string>command,int sign_i,int pass_i);
        int  find_user(string username);
        void  login(vector<string>command);
        void login_second_step(vector<string>command,int sign_i,int pass_i);
        void  Log_out();
        void  pushing_back_command(vector<string>command);
        void  Wallet(vector<string>command);
        bool  full_checker();
        void  Show_flights(vector<string>command);
        void Show_all_flights(vector<string>command);
        void Show_specific_flight(vector<string>command);
        void  Show_tickets(vector<string>command);
        void  buy(vector<string>command);
        void  cancel_ticket(vector<string>command);
        void  do_accepted_command(vector<string>command);
        void  do_commands(vector<vector<string>>splitted_commands);
        bool  username_existence(string username);
        void filter_first_step(vector<string>command);
        void  pushing_back_filter(vector<string>command);
        void delete_filters();
        void initializing_filter_vec();

    private:
        vector<Flight*>flights;
        vector< User*>users;
        vector<Filter *>filters;
        vector<Filter *>our_filters;
        vector<Flight *>filtered_flights;
        int signed_status;
        User * current_user;
        int tickets_num=0;

};
#endif