#include"user.hpp"
#include<iostream>
#include<string>
#define ERR -1

const string INVALID_COMMAND_FORM="Bad Request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string BUSINESS="business";
const string ECO="economy";
const string REF="refundable";
const string NON_REF="nonrefundable";

User :: User(string name,string pass){
    username=name;
    password=pass;
    wallet_money=0;
}

string User:: get_username(){
    return username;
}

void User:: charge_wallet(float amount){
    wallet_money+=amount;
}

bool check_seat_ok(Ticket * new_tick){
    Flight * this_flight=new_tick->get_flight();
    if(new_tick->get_class()==BUSINESS){
        if(this_flight->get_business_seats() <= new_tick->get_quantity())
            return false;
    }
    else{
        if(this_flight->get_economy_seats() <= new_tick->get_quantity()){            
            return false;
        }
    }
    return true;
}

void User :: calculate_left_money(Ticket *new_tick){
    wallet_money -=new_tick->get_cost();
}

void User :: change_seats(Ticket * new_tick){
    Flight * this_flight=new_tick->get_flight();
    if(new_tick->get_class()==BUSINESS)
        this_flight->change_business_seat_num((new_tick->get_quantity())*(-1));
    else
        this_flight->change_economy_seat_num((new_tick->get_quantity())*(-1));
}

void User ::buy_ticket(vector<string>command,vector<Flight*>flights,int tick_num,int flight_index,int quantity_index,int class_index,int type_index){
    Ticket * new_tick=new Ticket(command,flights,flight_index,quantity_index,class_index,type_index);
    if (wallet_money < new_tick->get_cost())
        throw(INVALID_COMMAND_FORM);
    if(!check_seat_ok(new_tick)){
        throw(INVALID_COMMAND_FORM);
    }
    calculate_left_money(new_tick);
    change_seats(new_tick);
    new_tick->set_id(tick_num+1);
    tickets.push_back(new_tick);
}

void User:: print_this_ticket(int i){
    int index=find_ticket(i);
    if(index==ERR)
        throw(NON_ACCEPTABLE_COMMAND);
    else
        tickets[index]->print();
}

void User:: print_tickets(){
    if(tickets.size()==0)
        throw(EMP);
    else{
        for(int i=0;i<tickets.size();i++){
            tickets[i]->print();
        }       
    }
}

int User:: find_ticket(int id){
    for(int i=0;i<tickets.size();i++){
        if(tickets[i]->get_id()==id)
            return i;
    }
    return ERR;
}

Ticket* User:: cancel_a_ticket(int id){
    int the_ticket=find_ticket(id);
    if(the_ticket==(ERR)){
        throw(NON_ACCEPTABLE_COMMAND);
    }
    if(tickets[the_ticket]->get_type()==NON_REF){
        throw(INVALID_COMMAND_FORM);
    }
    Flight * this_tick_flight=tickets[the_ticket]->get_flight();
    if(tickets[the_ticket]->get_class()==BUSINESS){
        this_tick_flight->change_business_seat_num(tickets[the_ticket]->get_quantity());
        wallet_money+=(0.5)*tickets[the_ticket]->get_cost();
    }
    if(tickets[the_ticket]->get_class()==ECO){
        this_tick_flight->change_economy_seat_num(tickets[the_ticket]->get_quantity());
        wallet_money+=(0.5)*tickets[the_ticket]->get_cost();
    }
    Ticket * this_tick_=tickets[the_ticket];
    tickets.erase(tickets.begin()+the_ticket); 
    return this_tick_;
}

string User:: get_password(){
    return password;
}

Ticket * User :: get_ticket(int id){
    for(int i=0;i<tickets.size();i++){
        if(tickets[i]->get_id()==id)
            return tickets[i];
    }
    return NULL;
}

User :: ~User(){
    for(auto ticket :tickets)
        delete ticket;
}
