#include"filter.hpp"

Filter :: Filter(){

}