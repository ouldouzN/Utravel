#include"connecting_flight.hpp"
#include<iostream>

const string CONNECT_DUR="Connection duration";
const string TOT_COST="Total cost";
const string DASH_SEP="----------";

Connecting_Flight :: Connecting_Flight(Flight * first,Flight *second,int duration){
    first_flight=first;
    second_flight=second;
    connection_duration=duration;
    total_cost=first->get_cost()+second->get_cost();
}

void Connecting_Flight :: print(){
    cout<<"Flight 1: ";
    first_flight->print_flight_info();
    cout<<"Flight 2: ";
    second_flight->print_flight_info();
    int hours=connection_duration/60;
    int mins=connection_duration-hours*60;
    if(mins==0)
        cout<<"* "<<CONNECT_DUR<<": "<<hours<<"h"<<", ";    
    else
        cout<<"* "<<CONNECT_DUR<<": "<<hours<<"h"<<" "<<mins<<"m"<<", ";
    cout<<TOT_COST<<": "<<((float)((int)(total_cost*100)))/100.0<<endl;    
}

float Connecting_Flight::get_cost(){
    return total_cost;
}

Flight * Connecting_Flight:: get_first_flight(){
    return first_flight;
}
Flight * Connecting_Flight :: get_second_flight(){
    return second_flight;
}
