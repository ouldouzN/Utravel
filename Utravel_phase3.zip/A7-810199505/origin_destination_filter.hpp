#ifndef _Origin_destination_HPP_
#define _Origin_destination_HPP_

#include<iostream>
#include<string>

using namespace std;

class origin_destination_filter {
    public:
        origin_destination_filter();
        void apply_filter(string origin,string destination,vector<Flight*>flights);
        
    private:
        string origin;
        string destination;

};

#endif

