#ifndef _UT_HPP_
#define _UT_HPP_
#include"flight.hpp"
#include"user.hpp"
#include"filter.hpp"
#include"origin_destination_filter.hpp"
#include"cost_filter.hpp"
#include"airline_filter.hpp"
#include"date_filter.hpp"
#include"ticket.hpp"
#include"connecting_flight.hpp"

#include<vector>
#include<string>

using namespace std;

struct Destination{
    string name;
    int ticket_num;
};

struct Airline{
    string name;
    int ticket_num;
};

class User;

class Utravel{
    public:
        Utravel(vector<vector<string>>utravel_flights,vector<vector<string>>splitted_commands);
        ~Utravel();
        void Sign_Up(vector<string>command);
        void Sign_Up_second_step(vector<string>command,int sign_i,int pass_i);
        int  find_user(string username);
        void  login(vector<string>command);
        void login_second_step(vector<string>command,int sign_i,int pass_i);
        void  Log_out();
        void  pushing_back_command(vector<string>command);
        void  Wallet(vector<string>command);
        bool  full_checker();
        void  Show_flights(vector<string>command);
        void Show_all_flights(vector<string>command);
        void Show_specific_flight(vector<string>command);
        void  Show_tickets(vector<string>command);
        void  buy(vector<string>command);
        void  cancel_ticket(vector<string>command);
        void  do_accepted_command(vector<string>command);
        void  do_commands(vector<vector<string>>splitted_commands);
        bool  username_existence(string username);
        void filter_first_step(vector<string>command);
        void  pushing_back_filter(vector<string>command);
        void delete_filters();
        void initializing_filter_vec();
        void get_report();
        float calculate_avg_cost();
        int find_in_dests(string this_flight_dest);
        int find_in_airlines(string this_flight_airline);
        void put_in_destination_struct(int flight_index,int quantity,int state);
        void put_in_airline_struct(int flight_index,int quantity,int state);
        float find_min_cost();
        float find_max_cost();
        int find_most_popular_dest();
        void sort_airlines();
        vector<string> find_best_airlines();
        void print_report(string most_popular_dest,vector<string>best_airlines);
        void check_sameday_connect(Flight *first_flight,Flight* second_flight,vector<Connecting_Flight*>&connect_flights);
        void check_diffday_connect(Flight * first_flight,Flight *second_flight,vector<Connecting_Flight*>&connect_flights);
        void check_connectibility(Flight * first_flight,Flight *second_flight,vector<Connecting_Flight*>&connect_flights);
        vector<Connecting_Flight *>  connect_if_ok(vector<Flight*>first_flights,vector<Flight*>second_flight);
        vector<Connecting_Flight *> collect_flights_for_connect(vector<string>command,int from_index,int to_index,int date_index);
        void print_connect_flights(vector<Connecting_Flight*>connect_flights);
        void find_connecting_flight(vector<string>command);
        vector<Flight *> find_matching_flights(vector<string>command,int from_index,int to_index,int date_index);
        int find_cheapest_index(vector<Flight *>flights);
        int find_cheapest_connecting_index(vector<Connecting_Flight *>flights);
        void find_cheapest(vector<string>command);
        void sort_connect_flights(vector<Connecting_Flight *>&flights);
        void find_cheapest_straight(vector<Flight*>wanted_flights);
        void find_cheapest_both(vector<Flight*>wanted_flights,vector<Connecting_Flight*>wanted_connecting_flights);
        void find_cheapest_connecting(vector<Connecting_Flight*>wanted_connecting_flights);

    private:
        vector<Flight*>flights;
        vector< User*> users;
        vector<Filter *> filters;
        vector<Destination>destinations;
        vector<Airline>airlines;
        int signed_status;
        User * current_user;
        int tickets_num=0;
        float avg_cost;
        float min_flight_cost;
        float max_flight_cost;
        string most_popular_destination;

};
#endif