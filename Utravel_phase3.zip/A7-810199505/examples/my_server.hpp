#include "../server/server.hpp"

class MyServer : public Server {
public:
  MyServer(int port = 5000);
};
