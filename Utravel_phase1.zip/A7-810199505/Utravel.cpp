#include"Utravel.hpp"
#include"filter.hpp"
#include"origin_destination_filter.hpp"
#include"cost_filter.hpp"
#include"airline_filter.hpp"
#include"date_filter.hpp"
#include<string>
#include<iostream>

#define APPLIED 1
#define ERR -1
using namespace std;

const string INVALID_COMMAND_FORM="Bad request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string UN="username";
const string PASS="password";
const string AMOUNT="amount";
const string ID="id";
const string POST="POST";
const string DEL="DELETE";
const string GET="GET";
const string SIGN_UP="signup";
const string LOGIN="login";
const string LOGOUT="logout";
const string WALLET="wallet";
const string FLIGHTS="flights";
const string TICKS="tickets";
const string FILTERS="filters";
const string AIRLINE ="airline";
const string MIN_PRC="min_price";
const string MAX_PRC="max_price";
const string DEP_DATE="departure_date";
const string MIN_TIME="min_departure_time";
const string MAX_TIME="max_departure_time";
const string FROM="from";
const string TO="to";
const string CLASS="class";
const string TYPE="type";
const string QUANT="quantity";
const string FLIGHT="flight";


Utravel :: Utravel(vector<vector<string>>utravel_flights,vector<vector<string>>splitted_commands){
    for(int i=0;i<utravel_flights.size();i++){
        Flight * temp=new Flight(utravel_flights[i],i+1);
        flights.push_back(temp);
    }
    filtered_flights=flights;
    do_commands(splitted_commands);
    tickets_num=0;
}
bool Utravel:: username_existence(string username){
    for(int i=0;i<users.size();i++){
        if(users[i]->get_username()==username)
            return true;
    }
    return false;

}
void Utravel :: Sign_Up_second_step(vector<string>command,int sign_i,int pass_i){
    if(username_existence(command[sign_i])){
        throw (INVALID_COMMAND_FORM);
    }
    else{
        User * new_user=new User(command[sign_i],command[pass_i]);
        users.push_back(new_user);
        current_user=new_user;
        signed_status=1;
        cout<<acceptable_command<<endl;
    }    
}
void Utravel :: Sign_Up(vector<string>command){   
    if(command.size()==7){
        if(command[3]==UN && command[5]==PASS){
            Sign_Up_second_step(command,4,6);
        }
        else if(command[5]==UN && command[3]==PASS){
            Sign_Up_second_step(command,6,4);
        }
        else {
            throw(INVALID_COMMAND_FORM);
        }
    }
    else{
        throw (INVALID_COMMAND_FORM);
    }
}
int Utravel:: find_user(string username){
    for(int i=0;i<users.size();i++){
        if(users[i]->get_username()==username)
            return i;
    }
    return ERR;

}
void Utravel :: login_second_step(vector<string>command,int sign_i,int pass_i){
    if(username_existence(command[sign_i])==false){
        throw(INVALID_COMMAND_FORM);
    }
    else{
        int user_index=find_user(command[sign_i]);
        if(users[user_index]->get_password()==command[pass_i]){
            current_user=users[user_index];
            signed_status=1;
            cout<<acceptable_command<<endl;
        }
        else
            throw(INVALID_COMMAND_FORM);
                
    }
}

void Utravel:: login(vector<string>command){   
    if(command.size()==7 && signed_status==0){
        if(command[3]==UN && command[5]==PASS){
            login_second_step(command,4,6);
        }
        else if(command[5]==UN && command[3]==PASS){
            login_second_step(command,6,4);
        }
        else {
            throw(INVALID_COMMAND_FORM);
        }
    }
    else{
        throw (INVALID_COMMAND_FORM);
    }
}
void Utravel :: Log_out(){
    if(signed_status==1){
        current_user=NULL;
        signed_status=0;
        cout<<acceptable_command<<endl;
    }
    else{
        throw(PER_DENY);
    }    
}

void Utravel:: Wallet(vector<string>command){   
    if(command.size()==5 && command[3]==AMOUNT){
        if(stof(command[4])>0){
            if(signed_status==1){
                current_user->charge_wallet(stof(command[4]));
                cout<<acceptable_command<<endl;
            }
            else
                throw(PER_DENY);
        }
        else
            throw(INVALID_COMMAND_FORM);
    }
    else
        throw(INVALID_COMMAND_FORM);   
}

bool Utravel :: full_checker(){
    int checker=0;
    for(int i=0;i<filtered_flights.size();i++){
        if(flights[i]->get_seats()!=0 && flights[i]->get_airline_ok()==1 &&
        flights[i]->get_cost_ok()==1 && flights[i]->get_date_ok()==1 &&
        flights[i]->get_origin_ok()==1)
            checker+=1;
    }
    if(checker==0)
        return true;
    else
        return false;
}
void Utravel::Show_all_flights(vector<string>command){
    if(full_checker() || flights.size()==0){
        cout<<EMP<<endl;
    }
    else{
        for(int i=0;i<flights.size();i++){
            if(flights[i]->get_seats()!=0 && flights[i]->get_airline_ok()==1 &&
            flights[i]->get_cost_ok()==1 && flights[i]->get_date_ok()==1 &&
            flights[i]->get_origin_ok()==1){
                flights[i]->print_flight_info();
            }
        }
    }
}

void Utravel::Show_specific_flight(vector<string>command){
    if(stoi(command[4])>flights.size())
        throw(NON_ACCEPTABLE_COMMAND);
    if(command[3]==ID){
        flights[stoi(command[4])-1]->print_flight_info();
    }
    else
        throw(INVALID_COMMAND_FORM);
}

void Utravel:: Show_flights(vector<string>command){
        if(signed_status==0){
            throw(PER_DENY);
        }
        if(command.size()==2){
            Show_all_flights(command);
        }
        else if(command.size()==5){
            Show_specific_flight(command);
        }
        else
            throw(INVALID_COMMAND_FORM);    
}

void Utravel :: delete_filters(){
    if(signed_status==1){
        cout<<acceptable_command<<endl;
        for(int i=0;i<flights.size();i++){
            flights[i]->set_airline_ok(APPLIED);
            flights[i]->set_cost_ok(APPLIED);
            flights[i]->set_origin_ok(APPLIED);
            flights[i]->set_date_ok(APPLIED);
        }
    }
    else
        throw(PER_DENY);
}

void Utravel :: initializing_filter_vec(){
    origin_destination_filter * od_filter=new origin_destination_filter();
    Cost_filter * C_filter=new Cost_filter();
    Airline_filter * A_filter=new Airline_filter();
    Date_filter * D_filter=new Date_filter();
    filters.push_back(od_filter);
    filters.push_back(C_filter);
    filters.push_back(A_filter);
    filters.push_back(D_filter);
}

void Utravel:: Show_tickets(vector<string>command){    
    if(signed_status==0){
        throw(PER_DENY);
    }
    if(command.size()==2){
        current_user->print_tickets();
    }
    else if(command.size()==5){
        if(command[3]==ID)
            current_user->print_this_ticket(stoi(command[4]));
        else
            throw(INVALID_COMMAND_FORM);
    }
    else
        throw(INVALID_COMMAND_FORM);   
}

int find_argument(vector<string>command,string argumnet){
    for(int i=0;i<command.size();i++){
        if(command[i]==argumnet)
            return i;
    }
    return ERR;
}
void Utravel :: buy(vector<string>command){
    if(signed_status==0){
        throw(PER_DENY);
    }
    else{
        if(command.size()==11){
            int flight_index=find_argument(command,FLIGHT);
            int quantity_index=find_argument(command,QUANT);
            int class_index=find_argument(command,CLASS);
            int type_index=find_argument(command,TYPE);
            if(flight_index!=ERR && quantity_index!=ERR && class_index!=ERR && type_index!=ERR){
                current_user->buy_ticket(command,flights,tickets_num,flight_index+1,quantity_index+1,class_index+1,type_index+1);
                tickets_num+=1;
                cout<<tickets_num<<endl;
            }
            else{
                throw(INVALID_COMMAND_FORM);
            }
        }
        else{
            throw(NON_ACCEPTABLE_COMMAND);
        }
    }
}

void Utravel:: cancel_ticket(vector<string>command){
    if(signed_status==0){
        throw(PER_DENY);
    }
    else{
        if(command.size()==5){
            current_user->cancel_a_ticket(stoi(command[4]));
            cout<<acceptable_command<<endl;
        }
        else{
            throw(INVALID_COMMAND_FORM);
        }
    }
}

void Utravel:: pushing_back_filter(vector<string>command){
    initializing_filter_vec();
    for(int i=0;i<4;i++){
        filters[i]->apply_filter(command,flights);        
    }
    cout<<acceptable_command<<endl;
}
void Utravel:: filter_first_step(vector<string>command){
    if(command.size()>=5 && (command[3]==AIRLINE ||
    command[3]==FROM || command[3]==DEP_DATE || command[3]==MIN_PRC
    || command[3]==MAX_PRC || command[3]==TO || command[3]==MIN_TIME
    || command[3]==MAX_TIME)){
        pushing_back_filter(command);
    }
    else
        throw(INVALID_COMMAND_FORM);
}
void Utravel :: do_accepted_command(vector<string>command){
    try{
        if(command[0]==POST && command[1]==SIGN_UP)
            Sign_Up(command);
        else if (command[0]==POST && command[1]==LOGIN)
            login(command);
        else if (command[0]==POST && command[1]==LOGOUT)
            Log_out();    
        else if (command[0]==POST && command[1]==WALLET)
            Wallet(command);    
        else if (command[0]==GET && command[1]==FLIGHTS)
            Show_flights(command);
        else if(command[0]==POST && command[1]==TICKS && command.size()==11)
            buy(command);
        else if(command[0]==GET && command[1]==TICKS)
            Show_tickets(command);
        else if(command[0]==DEL && command[1]==TICKS)
            cancel_ticket(command);
        else if(command[0]==POST && command[1]==FILTERS){
            filter_first_step(command);
        }
        else if(command[0]==DEL&& command[1]==FILTERS)
            delete_filters();
        else
            throw(NON_ACCEPTABLE_COMMAND);
    }
    catch(string err_txt){
        cout<<err_txt<<endl;
    }
}

void  Utravel :: do_commands(vector<vector<string>>splitted_commands){
    for(int i=0;i<splitted_commands.size();i++){
        try{
            if(splitted_commands[i][0]==GET ||splitted_commands[i][0]==POST || splitted_commands[i][0]==DEL ){
                do_accepted_command(splitted_commands[i]);
            }
            else{
                throw(INVALID_COMMAND_FORM); 
            }
        }
        catch(string error_txt){
            cout<<error_txt<<endl;
        }
    }
} 