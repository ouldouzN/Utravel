#ifndef _COST_HPP_
#define _COST_HPP_

#include<iostream>
#include<string>

using namespace std;

class Cost_filter : public Filter{
    public:
        Cost_filter();
        virtual void apply_filter(vector<string>com,vector<Flight*>flights);
        void apllying_min_or_max_price(vector<string>com,vector<Flight*>flights);
        void apllying_max_and_min_price(vector<string>com,vector<Flight*>flights);
        void apllying_min_and_max_price(vector<string>com,vector<Flight*>flights);
        
    private:
        float min;
        float max;
};

#endif