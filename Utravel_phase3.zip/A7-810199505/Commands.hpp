#ifndef CMD_HPP
#define CMD_HPP

#include"Utravel.hpp"

class Command{
    public:
        Command(vector<vector<string>>splitted_flights);
        void Run();
        Utravel * get_Utravel_ptr();
    private:
        Utravel * my_utravel;

};

#endif