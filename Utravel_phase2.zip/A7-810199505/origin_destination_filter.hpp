#ifndef _Origin_destination_HPP_
#define _Origin_destination_HPP_

#include<iostream>
#include<string>

using namespace std;

class origin_destination_filter : public Filter{
    public:
        origin_destination_filter();
        virtual void apply_filter(vector<string>com,vector<Flight*>flights);
        
    private:
        string origin;
        string destination;

};

#endif

