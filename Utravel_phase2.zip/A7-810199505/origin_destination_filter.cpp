#include"filter.hpp"
#include"origin_destination_filter.hpp"
#include"cost_filter.hpp"
#include"airline_filter.hpp"
#include"date_filter.hpp"

#define APPLIED 1
#define UNAPPLIED 0

const string INVALID_COMMAND_FORM="Bad Request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string FROM="from";
const string TO="to";

origin_destination_filter ::origin_destination_filter(): Filter(){
    applied_state=UNAPPLIED;
}

void origin_destination_filter ::apply_filter(vector<string>com,vector<Flight*>flights){
    if(com[3]!=FROM && com[3]!=TO){
        return ;
    }
    if(com.size()!=7)
        throw(INVALID_COMMAND_FORM);
    if(com[3]==FROM && com[5]==TO){
        for(int j=0;j<flights.size();j++)
            flights[j]->set_origin_ok(APPLIED);
        for(int i=0;i<flights.size();i++){
            if(flights[i]->get_origin()!=com[4] || flights[i]->get_destination()!=com[6])
                flights[i]->set_origin_ok(UNAPPLIED);
        }
    }
    else if(com[5]==FROM && com[3]==TO){
        for(int j=0;j<flights.size();j++)
            flights[j]->set_origin_ok(APPLIED);
        for(int i=0;i<flights.size();i++){
            if(flights[i]->get_origin()!=com[6] || flights[i]->get_destination()!=com[4])
                flights[i]->set_origin_ok(UNAPPLIED);
        }
    }
    else
        throw(INVALID_COMMAND_FORM);
}