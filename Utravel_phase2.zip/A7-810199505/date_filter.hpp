#ifndef _DATE_HPP_
#define _DATE_HPP_

#include<iostream>
#include<string>

using namespace std;

class Date_filter : public Filter{
    public:
        Date_filter();
        virtual void apply_filter(vector<string>com,vector<Flight*>flights);
        void apply_dep_date(vector<string>com,vector<Flight*>flights);
        void apply_min_time(vector<string>com,vector<Flight*>flights);
        void apply_max_time(vector<string>com,vector<Flight*>flights);
        void apply_complete_time_filter(vector<string>com,vector<Flight*>flights,int date_i,int min_i,int max_i);
        void divide_according_command(vector<string>com,vector<Flight*>flights);
    private:
        string deparure_date;
        int min_time;
        int max_time;

};

#endif