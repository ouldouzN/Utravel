#include"filter.hpp"
#include"date_filter.hpp"
#include<string>
#include<sstream>
#define APPLIED 1
#define UNAPPLIED 0

const string INVALID_COMMAND_FORM="Bad Request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string DEP_DATE="departure_date";
const string MIN_TIME="min_departure_time";
const string MAX_TIME="max_departure_time";

int convert_time_to_int(string time ){
    string temp_str;
    vector<int>temp_vec;
    stringstream X(time);
    while (getline(X, temp_str, ':')) {
        temp_vec.push_back(stoi(temp_str));
    }
    return temp_vec[0]*60+temp_vec[1];

}

Date_filter:: Date_filter(): Filter(){
    
}
void Date_filter :: apply_dep_date(vector<string>com,vector<Flight*>flights){
    for(int j=0;j<flights.size();j++){
        flights[j]->set_date_ok(APPLIED);
    }
    for(int i=0;i<flights.size();i++){
        if(flights[i]->get_departure_date()!=com[4] ){            
            flights[i]->set_date_ok(UNAPPLIED);
        }
    }
}
void Date_filter :: apply_min_time(vector<string>com,vector<Flight*>flights){
    if(com[3]==DEP_DATE &&com[5]==MIN_TIME){
        min_time=convert_time_to_int(com[6]);
        if(min_time<0 || min_time>1440)
            throw(INVALID_COMMAND_FORM);
        for(int j=0;j<flights.size();j++)
            flights[j]->set_date_ok(1);
        for(int i=0;i<flights.size();i++){
            int dep_time=convert_time_to_int(flights[i]->get_departure_time());
            if(flights[i]->get_departure_date()!=com[4] || dep_time<min_time )           
                flights[i]->set_date_ok(UNAPPLIED);
        }
    }   
    else if(com[5]==DEP_DATE &&com[3]==MIN_TIME){
        min_time=convert_time_to_int(com[4]);
        if(min_time<0 || min_time>1440)
            throw(INVALID_COMMAND_FORM);
        for(int j=0;j<flights.size();j++)
            flights[j]->set_date_ok(1);
        for(int i=0;i<flights.size();i++){
            int dep_time=convert_time_to_int(flights[i]->get_departure_time());
            if(flights[i]->get_departure_date()!=com[6] || dep_time<min_time )            
                flights[i]->set_date_ok(UNAPPLIED);
        }       
    }
}

void Date_filter :: apply_max_time(vector<string>com,vector<Flight*>flights){
    if(com[3]==DEP_DATE &&com[5]==MAX_TIME){
        int max_time=convert_time_to_int(com[6]);
        if(max_time<0 || max_time>1440)
            throw(INVALID_COMMAND_FORM);
        for(int j=0;j<flights.size();j++)
            flights[j]->set_date_ok(1);
        for(int i=0;i<flights.size();i++){
            int dep_time=convert_time_to_int(flights[i]->get_departure_time());
            if(flights[i]->get_departure_date()!=com[4] || dep_time>max_time )           
                flights[i]->set_date_ok(UNAPPLIED);
        }
    }   
    else if(com[5]==DEP_DATE &&com[3]==MAX_TIME){
        int max_time=convert_time_to_int(com[4]);
        if(max_time<0 || max_time>1440)
            throw(INVALID_COMMAND_FORM);
        for(int j=0;j<flights.size();j++)
            flights[j]->set_date_ok(1);
        for(int i=0;i<flights.size();i++){
            int dep_time=convert_time_to_int(flights[i]->get_departure_time());
            if(flights[i]->get_departure_date()!=com[6] || dep_time>max_time )            
                flights[i]->set_date_ok(UNAPPLIED);
        }       
    }
}
void Date_filter:: apply_complete_time_filter(vector<string>com,vector<Flight*>flights,int date_i,int min_i,int max_i){
    int min_time=convert_time_to_int(com[min_i]);
    int max_time=convert_time_to_int(com[max_i]);
    if(min_time<0 || max_time>1440 || max_time<min_time)
        throw(INVALID_COMMAND_FORM); 
    for(int j=0;j<flights.size();j++){
        flights[j]->set_date_ok(1);
    }          
    for(int i=0;i<flights.size();i++){
        int dep_time=convert_time_to_int(flights[i]->get_departure_time());
        int arr_time=convert_time_to_int(flights[i]->get_arrival_time());
        if(flights[i]->get_departure_date()!=com[date_i] || dep_time<min_time || dep_time>max_time){            
            flights[i]->set_date_ok(UNAPPLIED);
        }
    }   
}
void Date_filter:: divide_according_command(vector<string>com,vector<Flight*>flights){
        if(com[3]==DEP_DATE && com[5]==MIN_TIME && com[7]==MAX_TIME)
            apply_complete_time_filter(com,flights,4,6,8);
        else if(com[3]==DEP_DATE && com[7]==MIN_TIME && com[5]==MAX_TIME)
            apply_complete_time_filter(com,flights,4,8,6);
        else if(com[5]==DEP_DATE && com[3]==MIN_TIME && com[7]==MAX_TIME)
            apply_complete_time_filter(com,flights,6,4,8);
        else if(com[5]==DEP_DATE && com[7]==MIN_TIME && com[3]==MAX_TIME)
            apply_complete_time_filter(com,flights,6,8,4);
        else if(com[7]==DEP_DATE && com[3]==MIN_TIME && com[5]==MAX_TIME)
            apply_complete_time_filter(com,flights,8,4,6);
        else if(com[7]==DEP_DATE && com[5]==MIN_TIME && com[3]==MAX_TIME)
            apply_complete_time_filter(com,flights,8,6,4);
        else
            throw(INVALID_COMMAND_FORM);
}
void Date_filter ::apply_filter(vector<string>com,vector<Flight*>flights){
    if(com[3]!=DEP_DATE && com[3]!=MIN_TIME && com[3]!=MAX_TIME)
        return;
    if(com.size()==5 && com[3]==DEP_DATE)
        apply_dep_date(com,flights);
    else if(com.size()==7 ){
        if((com[3]==DEP_DATE &&com[5]==MIN_TIME)||
        (com[5]==DEP_DATE &&com[3]==MIN_TIME)) {
            apply_min_time(com,flights);
        }
        else if((com[3]==DEP_DATE &&com[5]==MAX_TIME)||
        (com[5]==DEP_DATE &&com[3]==MAX_TIME)) {
            apply_max_time(com,flights);
        }        
        else
            throw(INVALID_COMMAND_FORM);
    }
    else if(com.size()==9)
        divide_according_command(com,flights);
    else
        throw(INVALID_COMMAND_FORM);
}