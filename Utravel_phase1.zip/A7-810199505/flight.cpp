#include"flight.hpp"
#include<iostream>

#define APPLIED 1
#define UNAPPLIED 0


Flight :: Flight (vector<string>flight_info,int flight_id){
        airline=flight_info[0];
        origin=flight_info[1];
        destination=flight_info[2];
        departure_date=flight_info[3];
        departure_time=flight_info[4];
        arrival_date=flight_info[5];
        arrival_time=flight_info[6];
        business_seats=stoi(flight_info[7])/4;
        economy_seats=stoi(flight_info[7])-business_seats;
        cost=stof(flight_info[8]);
        id=flight_id;
        origin_destination_ok=APPLIED;
        cost_ok=APPLIED;
        date_ok=APPLIED;
        airline_ok=APPLIED;
}

void Flight :: set_origin_ok(int val){
        origin_destination_ok=val;
}
void Flight :: set_cost_ok(int val){
        cost_ok=val;
}
void Flight :: set_airline_ok(int val){
        airline_ok=val;
}
void Flight ::set_date_ok(int val){
        date_ok=val;
}
int Flight :: get_origin_ok(){
        return origin_destination_ok;
}
int Flight :: get_cost_ok(){
        return cost_ok;
}
int Flight :: get_date_ok(){
        return date_ok;
}
int Flight :: get_airline_ok(){
        return airline_ok;
}
int Flight :: get_economy_seats(){
        return economy_seats;
}
int Flight :: get_business_seats(){
        return business_seats;
}
void Flight :: print_flight_info(){
        cout<<id<<" "<<airline<<" "<<origin<<" "<<destination<<" "<<departure_date
        <<" "<<departure_time<<" "<<arrival_date<<" "<<arrival_time<<" "<<economy_seats+business_seats<<
        " "<<cost<<endl;
}
void Flight :: change_id(int new_id){
        id=new_id;
}
string Flight:: get_airline(){
        return airline;
}
string Flight ::get_origin(){
        return origin;
}
string Flight ::get_destination(){
        return destination;
}
string Flight:: get_departure_date(){
        return departure_date;
}
string Flight:: get_arrival_date(){
        return arrival_date;
}
string Flight :: get_departure_time(){
        return departure_time;
}
string Flight:: get_arrival_time(){
        return arrival_time;
}
float Flight ::get_cost(){
        return cost;
}
int Flight:: get_id(){
        return id;
}
string Flight:: get_kind(){
        return kind;

}
void Flight:: change_economy_seat_num(int num){
        economy_seats+=num;
}
void Flight :: change_business_seat_num(int num){
        business_seats+=num;
}
int Flight :: get_seats(){
        return business_seats+economy_seats;
}