#include"filter.hpp"
#include"airline_filter.hpp"
#include"exception.hpp"
#define APPLIED 1
#define UNAPPLIED 0

const string INVALID_COMMAND_FORM="Bad Request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string AIRLINE ="airline";
Airline_filter :: Airline_filter (){
}

void Airline_filter :: apply_filter(string Airline_name,vector<Flight*>flights){ 
    if(Airline_name=="")
        throw Bad_request();   
    for(int j=0;j<flights.size();j++){
        flights[j]->set_airline_ok(1);
    }
    for(int i=0;i<flights.size();i++){
        if(flights[i]->get_airline()!=Airline_name){
                flights[i]->set_airline_ok(0);
        }
    }
}