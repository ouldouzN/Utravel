#ifndef _COST_HPP_
#define _COST_HPP_

#include<iostream>
#include<string>
#include"exception.hpp"
using namespace std;

class Cost_filter{
    public:
        Cost_filter();
        void apply_filter(string min_price,string max_price,vector<Flight*>flights);
        void apllying_min_price(string min_price,vector<Flight*>flights);
        void apllying_max_price(string max_price,vector<Flight*>flights);
        void apllying_min_and_max_price(string min_price,string max_price,vector<Flight*>flights);
        
    private:
        float min;
        float max;
};

#endif