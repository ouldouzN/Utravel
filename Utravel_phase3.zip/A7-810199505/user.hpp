#ifndef _USER_HPP_
#define _USER_HPP_
#include<string>
#include"vector"
#include"ticket.hpp"
#include"Utravel.hpp"


using namespace std;

class User{
    public:
        User(string name,string pass);
        string get_username();
        void charge_wallet(float amount);
        void buy_ticket(int id,Flight* tick_flight,int quantity,string tick_class,string tick_type);
        string print_this_ticket(int id);
        string cancel_a_ticket(int id);
        string get_password();
        void set_id(int id);
        void calculate_left_money(Ticket * this_tick);
        void change_seats(Ticket * this_tick);
        int find_ticket(int i);
        Ticket * get_ticket(int id);
        float get_wallet_money();
        string  print_tickets();
    private:
        float wallet_money;
        vector<Ticket *>tickets;
        string username;
        string password;
};

#endif