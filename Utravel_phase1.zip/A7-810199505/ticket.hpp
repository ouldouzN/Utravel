#ifndef _TICK_HPP_
#define _TICK_HPP_
#include"flight.hpp"

class Ticket{
public:
    Ticket(vector<string>command,vector<Flight*>flights,int flight_index,int quantity_index,int class_index,int type_index);
    float get_cost();
    Flight * get_flight();
    string get_class();
    int get_quantity();
    void set_id(int tick_id);
    int get_id();
    void print();
    string get_type();

private:
    Flight *tick_flight;
    int quantity;
    string ticket_class;
    string ticket_type;
    int id;
    float cost;
};

#endif