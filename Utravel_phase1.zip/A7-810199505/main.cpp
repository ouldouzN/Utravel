#include<iostream>
#include<vector>
#include<fstream>
#include<string>
#include<sstream>
#include"Utravel.hpp"
using namespace std;

vector<string>get_flight_list(string file_name){
    ifstream MyReadFile(file_name);
    vector<string>temp_vec;
    string temp_str;
    while (getline (MyReadFile, temp_str)) {
        temp_vec.push_back(temp_str);
    }
    return temp_vec;
}

vector<vector<string>> split_flights(vector<string>primitive_flights){
    vector<vector<string>>splitted_flights;
    vector<string>temp_vec;
    for(int i=1;i<primitive_flights.size();i++){
        std ::string temp_str;
        stringstream X(primitive_flights[i]);
        while (getline(X, temp_str, ',')) {
            temp_vec.push_back(temp_str);
        }
        splitted_flights.push_back(temp_vec);
        temp_vec.clear();
    }
    return splitted_flights;
}

vector<string> get_commands(){
    vector<string>commands;
    string temp_str;
    while (getline (cin, temp_str)) {
        commands.push_back(temp_str);
    }
    return commands;
}
vector<vector<string>> split_commands(vector<string>commands){
    vector<vector<string>>splitted_commands;
    vector<string>temp_vec;
    for(int i=0;i<commands.size();i++){
        std ::string temp_str;
        stringstream X(commands[i]);
        while (getline(X, temp_str, ' ')) {
            temp_vec.push_back(temp_str);
        }
        splitted_commands.push_back(temp_vec);
        temp_vec.clear();
    }
    return splitted_commands;
}

int main(int argc,char * argv[]){
    vector<string>flights_primitive=get_flight_list(argv[1]+2);
    vector<vector<string>>splitted_flights=split_flights(flights_primitive);
    vector<string>primitive_commands=get_commands();
    vector<vector<string>>splitted_commands=split_commands(primitive_commands);
    Utravel  my_utravel(splitted_flights,splitted_commands);
    
}