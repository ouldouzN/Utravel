#include"ticket.hpp"
#include<iostream>
#include<sstream>

const string INVALID_COMMAND_FORM="Bad request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string BUSINESS="business";
const string ECO="economy";
const string REF="refundable";
const string NON_REF="nonrefundable";


Ticket :: Ticket(int id_,Flight* tick_flight_,int quantity_,string tick_class,string tick_type){
    float zarib=1;
    id=id_;
    tick_flight=tick_flight_;
    quantity=quantity_;
    ticket_class=tick_class;
    ticket_type=tick_type;
    if(ticket_class==BUSINESS)
        zarib=2.5;
    cost=zarib * quantity * (tick_flight->get_cost());   
}
Flight * Ticket:: get_flight(){
    return tick_flight;
}
float Ticket:: get_cost(){
    return cost;
}
string Ticket:: get_class(){
    return ticket_class;
}
int Ticket :: get_quantity(){
    return quantity;
}
void Ticket :: set_id(int tick_id){
    id=tick_id;
}
int Ticket :: get_id(){
    return id;
}

string Ticket :: print(){
    ostringstream ticket_;
    ticket_<<"<tr>"<<"<th scope='row'>"<<id<<"</th>"<<"<td>"<<tick_flight->get_id()<<
    "</td>"<<"<td>"<<quantity<<
    "</td>"<<"<td>"<<cost<<
    "</td>"<<"<td>"<<"<a href='/tick_full_info"<<"?id="<<id<<"'>"<<"details"<<"</a>"<<"</td>"<<
    "<a href='/cancel_tick"<<"?id="<<id<<"''style=' margin:auto; text-align:center; color: yellow;'>"<<"</td>"<<"/tr";
    return ticket_.str();
}

string Ticket:: print_full_info(){
    ostringstream body;
    body<<
"                <tr>"<<endl<<
"                   <td>"<<id<<"</th>"<<endl<<
"                   <td>"<<tick_flight->get_id()<<"</td>"<<endl<<
"                   <td>"<<quantity<<"</td>"<<endl<<
"                   <td>"<<ticket_class<<"</td>"<<endl<<
"                   <td>"<<ticket_type<<"</td>"<<endl<<
"                </tr>"<<endl<<
"                </table>"<<endl;
    return body.str();
}

string Ticket :: get_type(){
    return ticket_type;
}