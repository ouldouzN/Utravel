#include"Utravel.hpp"
#include"filter.hpp"
#include"origin_destination_filter.hpp"
#include"cost_filter.hpp"
#include"airline_filter.hpp"
#include"date_filter.hpp"
#include<string>
#include<iostream>
#include<sstream>

#define APPLIED 1
#define ERR -1
#define INCREASE 1
#define DECREASE -1
using namespace std;

const string INVALID_COMMAND_FORM="Bad Request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string UN="username";
const string PASS="password";
const string AMOUNT="amount";
const string ID="id";
const string POST="POST";
const string DEL="DELETE";
const string GET="GET";
const string SIGN_UP="signup";
const string LOGIN="login";
const string LOGOUT="logout";
const string WALLET="wallet";
const string FLIGHTS="flights";
const string TICKS="tickets";
const string FILTERS="filters";
const string AIRLINE ="airline";
const string MIN_PRC="min_price";
const string MAX_PRC="max_price";
const string DEP_DATE="departure_date";
const string MIN_TIME="min_departure_time";
const string MAX_TIME="max_departure_time";
const string FROM="from";
const string TO="to";
const string CLASS="class";
const string TYPE="type";
const string QUANT="quantity";
const string FLIGHT="flight";
const string AVG_COST="average_flight_cost";
const string MIN_COST="min_flight_cost";
const string MAX_COST="max_flight_cost";
const string POP_DEST="most_popular_destination";
const string TOP_AIRLINES="top_airlines";
const string CONNECT_FLT="connecting_flights";
const string CHEAP_FLT="cheapest_flight";
const string REP="overall_report";
const string DASH_SEP="----------";
const string TOT_COST="Total cost";

Utravel :: Utravel(vector<vector<string>>utravel_flights,vector<vector<string>>splitted_commands){
    for(int i=0;i<utravel_flights.size();i++){
        Flight * temp=new Flight(utravel_flights[i],i+1);
        flights.push_back(temp);
    }
    do_commands(splitted_commands);
    tickets_num=0;
    avg_cost=0;
    min_flight_cost=0;
    max_flight_cost=0;
}
Utravel :: ~Utravel(){
    for(auto flight : flights){
        delete flight;
    }
    for(auto user : users){
        delete user;
    }
    for(auto filter : filters){
        delete filter;
    }
}
bool Utravel:: username_existence(string username){
    for(int i=0;i<users.size();i++){
        if(users[i]->get_username()==username)
            return true;
    }
    return false;

}
void Utravel :: Sign_Up_second_step(vector<string>command,int sign_i,int pass_i){
    if(username_existence(command[sign_i])){
        throw (INVALID_COMMAND_FORM);
    }
    else{
        User * new_user=new User(command[sign_i],command[pass_i]);
        users.push_back(new_user);
        current_user=new_user;
        signed_status=1;
        cout<<acceptable_command<<endl;
    }    
}
void Utravel :: Sign_Up(vector<string>command){   
    if(command.size()==7){
        if(command[3]==UN && command[5]==PASS){
            Sign_Up_second_step(command,4,6);
        }
        else if(command[5]==UN && command[3]==PASS){
            Sign_Up_second_step(command,6,4);
        }
        else {
            throw(INVALID_COMMAND_FORM);
        }
    }
    else{
        throw (INVALID_COMMAND_FORM);
    }
}
int Utravel:: find_user(string username){
    for(int i=0;i<users.size();i++){
        if(users[i]->get_username()==username)
            return i;
    }
    return ERR;

}
void Utravel :: login_second_step(vector<string>command,int sign_i,int pass_i){
    if(username_existence(command[sign_i])==false){
        throw(INVALID_COMMAND_FORM);
    }
    else{
        int user_index=find_user(command[sign_i]);
        if(users[user_index]->get_password()==command[pass_i]){
            current_user=users[user_index];
            signed_status=1;
            cout<<acceptable_command<<endl;
        }
        else
            throw(INVALID_COMMAND_FORM);
                
    }
}

void Utravel:: login(vector<string>command){   
    if(command.size()==7 && signed_status==0){
        if(command[3]==UN && command[5]==PASS){
            login_second_step(command,4,6);
        }
        else if(command[5]==UN && command[3]==PASS){
            login_second_step(command,6,4);
        }
        else {
            throw(INVALID_COMMAND_FORM);
        }
    }
    else{
        throw (INVALID_COMMAND_FORM);
    }
}
void Utravel :: Log_out(){
    if(signed_status==1){
        current_user=NULL;
        signed_status=0;
        cout<<acceptable_command<<endl;
    }
    else{
        throw(PER_DENY);
    }    
}

void Utravel:: Wallet(vector<string>command){   
    if(command.size()==5 && command[3]==AMOUNT){
        if(stof(command[4])>0){
            if(signed_status==1){
                current_user->charge_wallet(stof(command[4]));
                cout<<acceptable_command<<endl;
            }
            else
                throw(PER_DENY);
        }
        else
            throw(INVALID_COMMAND_FORM);
    }
    else
        throw(INVALID_COMMAND_FORM);   
}

bool Utravel :: full_checker(){
    int checker=0;
    for(int i=0;i<flights.size();i++){
        if(flights[i]->get_seats()!=0 && flights[i]->get_airline_ok()==1 &&
        flights[i]->get_cost_ok()==1 && flights[i]->get_date_ok()==1 &&
        flights[i]->get_origin_ok()==1)
            checker+=1;
    }
    if(checker==0)
        return true;
    else
        return false;
}
void Utravel::Show_all_flights(vector<string>command){
    if(full_checker() || flights.size()==0){
        cout<<EMP<<endl;
    }
    else{
        for(int i=0;i<flights.size();i++){
            if(flights[i]->get_seats()!=0 && flights[i]->get_airline_ok()==1 &&
            flights[i]->get_cost_ok()==1 && flights[i]->get_date_ok()==1 &&
            flights[i]->get_origin_ok()==1){
                flights[i]->print_flight_info();
            }
        }
    }
}

void Utravel::Show_specific_flight(vector<string>command){
    if(stoi(command[4])>flights.size())
        throw(NON_ACCEPTABLE_COMMAND);
    if(command[3]==ID){
        flights[stoi(command[4])-1]->print_flight_info();
    }
    else
        throw(INVALID_COMMAND_FORM);
}

void Utravel:: Show_flights(vector<string>command){
        if(signed_status==0){
            throw(PER_DENY);
        }
        if(command.size()==2){
            Show_all_flights(command);
        }
        else if(command.size()==5){
            Show_specific_flight(command);
        }
        else
            throw(INVALID_COMMAND_FORM);    
}

void Utravel :: delete_filters(){
    if(signed_status==1){
        cout<<acceptable_command<<endl;
        for(int i=0;i<flights.size();i++){
            flights[i]->set_airline_ok(APPLIED);
            flights[i]->set_cost_ok(APPLIED);
            flights[i]->set_origin_ok(APPLIED);
            flights[i]->set_date_ok(APPLIED);
        }
    }
    else
        throw(PER_DENY);
}

void Utravel :: initializing_filter_vec(){
    origin_destination_filter * od_filter=new origin_destination_filter();
    Cost_filter * C_filter=new Cost_filter();
    Airline_filter * A_filter=new Airline_filter();
    Date_filter * D_filter=new Date_filter();
    filters.push_back(od_filter);
    filters.push_back(C_filter);
    filters.push_back(A_filter);
    filters.push_back(D_filter);
}

void Utravel:: Show_tickets(vector<string>command){    
    if(signed_status==0){
        throw(PER_DENY);
    }
    if(command.size()==2){
        current_user->print_tickets();
    }
    else if(command.size()==5){
        if(command[3]==ID)
            current_user->print_this_ticket(stoi(command[4]));
        else
            throw(INVALID_COMMAND_FORM);
    }
    else
        throw(INVALID_COMMAND_FORM);   
}

int find_argument(vector<string>command,string argumnet){
    for(int i=0;i<command.size();i++){
        if(command[i]==argumnet)
            return i;
    }
    return ERR;
}
int Utravel :: find_in_dests(string this_flight_dest){
    for(int i=0;i<destinations.size();i++){
        if(destinations[i].name==this_flight_dest)
            return i;
    }
    return ERR;

}
void Utravel :: put_in_destination_struct(int flight_index,int quantity,int state){
    string this_flight_dest=flights[flight_index-1]->get_destination();
    int index=find_in_dests(this_flight_dest);
    if(index != ERR){
        destinations[index].ticket_num+=(state)*quantity;
    }
    else{
        Destination new_dest;
        new_dest.name=this_flight_dest;
        new_dest.ticket_num=quantity;
        destinations.push_back(new_dest);
    }
}
int Utravel:: find_in_airlines(string this_flight_airline){
    for(int i=0;i<airlines.size();i++){
        if(airlines[i].name==this_flight_airline)
            return i;
    }
    return ERR;    
}
void Utravel :: put_in_airline_struct(int flight_index,int quantity,int state){
    string this_flight_airline=flights[flight_index-1]->get_airline();
    int index=find_in_airlines(this_flight_airline);
    if(index != ERR){
        airlines[index].ticket_num+=quantity*(state);
    }
    else{
        Airline new_airline;
        new_airline.name=this_flight_airline;
        new_airline.ticket_num=quantity;
        airlines.push_back(new_airline);
    }
}

void Utravel :: buy(vector<string>command){
    if(signed_status==0){
        throw(PER_DENY);
    }
    else{
        if(command.size()==11){
            int flight_index=find_argument(command,FLIGHT);
            int quantity_index=find_argument(command,QUANT);
            int class_index=find_argument(command,CLASS);
            int type_index=find_argument(command,TYPE);
            if(flight_index!=ERR && quantity_index!=ERR && class_index!=ERR && type_index!=ERR){
                put_in_destination_struct(stoi(command[flight_index+1]),stoi(command[quantity_index+1]),INCREASE);
                put_in_airline_struct(stoi(command[flight_index+1]),stoi(command[quantity_index+1]),INCREASE);
                current_user->buy_ticket(command,flights,tickets_num,flight_index+1,quantity_index+1,class_index+1,type_index+1);
                tickets_num+=1;
                cout<<tickets_num<<endl;
            }
            else{
                throw(INVALID_COMMAND_FORM);
            }
        }
        else{
            throw(NON_ACCEPTABLE_COMMAND);
        }
    }
}

void Utravel:: cancel_ticket(vector<string>command){
    if(signed_status==0){
        throw(PER_DENY);
    }
    else{
        if(command.size()==5){
            
            Ticket * this_tick=current_user->cancel_a_ticket(stoi(command[4]));
            cout<<acceptable_command<<endl;
            Flight * this_tick_flight=this_tick->get_flight();
            int corr_flight=this_tick->get_flight()->get_id();
            int quantity=this_tick->get_quantity();
            put_in_destination_struct(corr_flight,quantity,DECREASE);
            put_in_airline_struct(corr_flight,quantity,DECREASE);
        }
        else{
            throw(INVALID_COMMAND_FORM);
        }

    }
}

void Utravel:: pushing_back_filter(vector<string>command){
    initializing_filter_vec();
    for(int i=0;i<4;i++){
        filters[i]->apply_filter(command,flights);        
    }
    cout<<acceptable_command<<endl;
}
void Utravel:: filter_first_step(vector<string>command){
    if(command.size()>=5 && (command[3]==AIRLINE ||
    command[3]==FROM || command[3]==DEP_DATE || command[3]==MIN_PRC
    || command[3]==MAX_PRC || command[3]==TO || command[3]==MIN_TIME
    || command[3]==MAX_TIME)){
        pushing_back_filter(command);
    }
    else
        throw(INVALID_COMMAND_FORM);
}
void Utravel :: do_accepted_command(vector<string>command){
    try{
        if(command[0]==POST && command[1]==SIGN_UP)
            Sign_Up(command);
        else if (command[0]==POST && command[1]==LOGIN)
            login(command);
        else if (command[0]==POST && command[1]==LOGOUT)
            Log_out();    
        else if (command[0]==POST && command[1]==WALLET)
            Wallet(command);    
        else if (command[0]==GET && command[1]==FLIGHTS)
            Show_flights(command);
        else if(command[0]==POST && command[1]==TICKS && command.size()==11)
            buy(command);
        else if(command[0]==GET && command[1]==TICKS)
            Show_tickets(command);
        else if(command[0]==DEL && command[1]==TICKS)
            cancel_ticket(command);
        else if(command[0]==POST && command[1]==FILTERS){
            filter_first_step(command);
        }
        else if(command[0]==DEL&& command[1]==FILTERS)
            delete_filters();
        else if(command[0]==GET && command[1]==CONNECT_FLT)
            find_connecting_flight(command);
        else if(command[0]==GET && command[1]==CHEAP_FLT)
            find_cheapest(command);    
        else if(command[0]==GET && command[1]==REP)  
            get_report(); 
        else
            throw(NON_ACCEPTABLE_COMMAND);
    }
    catch(string err_txt){
        cout<<err_txt<<endl;
    }
}

void  Utravel :: do_commands(vector<vector<string>>splitted_commands){
    for(int i=0;i<splitted_commands.size();i++){
        try{
            if(splitted_commands[i][0]==GET ||splitted_commands[i][0]==POST || splitted_commands[i][0]==DEL ){
                do_accepted_command(splitted_commands[i]);
            }
            else{
                throw(INVALID_COMMAND_FORM); 
            }
        }
        catch(string error_txt){
            cout<<error_txt<<endl;
        }
    }
} 
float Utravel::calculate_avg_cost(){
    float sum=0;
    for(int i=0;i<flights.size();i++){
        sum+=flights[i]->get_cost();
    }
    return sum/(flights.size());
}
float Utravel :: find_min_cost(){
    float min_cost=flights[0]->get_cost();
    for(int i=1;i<flights.size();i++){
        if(flights[i]->get_cost() < min_cost)
            min_cost=flights[i]->get_cost();
    }
    return min_cost;
}
float Utravel :: find_max_cost(){
    float max_cost=flights[0]->get_cost();
    for(int i=1;i<flights.size();i++){
        if(flights[i]->get_cost() > max_cost)
            max_cost=flights[i]->get_cost();
    }
    return max_cost;   
}
int Utravel:: find_most_popular_dest(){
    int best_index=0;
    for(int i=1;i<destinations.size();i++){
        if(destinations[i].ticket_num > destinations[best_index].ticket_num)
            best_index=i;
    }
    return best_index;
}
void Utravel::sort_airlines(){
    Airline temp_airline;
    for(int i=0;i<airlines.size();i++){
        for(int j=0;j<airlines.size()-1;j++){
            if(airlines[j].ticket_num<airlines[j+1].ticket_num){
                temp_airline=airlines[j];
                airlines[j]=airlines[j+1];
                airlines[j+1]=temp_airline;
            }
        }
    }
}
vector<string> Utravel:: find_best_airlines(){
    sort_airlines();
    vector<string> best_airlines;
    if(airlines.size()<3){
        for(int j=0;j<airlines.size();j++){
            best_airlines.push_back(airlines[j].name);
        } 
    }
    else{
        for(int i=0;i<3;i++){
            best_airlines.push_back(airlines[i].name);
        }
    }

    return best_airlines;
}

void Utravel:: print_report(string most_popular_dest,vector<string>best_airlines){
    cout<< AVG_COST <<": "<<avg_cost<<endl;
    cout<< MIN_COST <<": "<<min_flight_cost<<endl;
    cout<< MAX_COST <<": "<<max_flight_cost<<endl;
    cout<< POP_DEST <<": "<<most_popular_dest<<endl;
    cout<< TOP_AIRLINES <<":";
    if(best_airlines.size()<3){
        for(int j=0;j<best_airlines.size();j++){
            cout<<best_airlines[j]<<" ";
        }        
    }
    else{
        for(int i=0;i<3;i++){
            cout<<" "<<best_airlines[i];
        }
    }
    cout<<endl;
}
void Utravel :: get_report(){
    int int_avg_cost=calculate_avg_cost()*100;
    avg_cost =(float)(int_avg_cost/100.0);
    int int_min_flight_cost=find_min_cost()*100;
    min_flight_cost=(float)(int_min_flight_cost/100.0);
    int int_max_flight_cost=find_max_cost()*100;
    max_flight_cost=(float)(int_max_flight_cost/100.0);
    int best_popular_dest=find_most_popular_dest();
    most_popular_destination=destinations[best_popular_dest].name;
    vector<string>best_airlines=find_best_airlines();
    print_report(most_popular_destination,best_airlines);
}

int convert_time_to_int2(string time ){
    string temp_str;
    vector<int>temp_vec;
    stringstream X(time);
    while (getline(X, temp_str, ':')) {
        temp_vec.push_back(stoi(temp_str));
    }
    return temp_vec[0]*60+temp_vec[1];

}
void Utravel:: check_sameday_connect(Flight * first_flight,Flight * second_flight,vector<Connecting_Flight*>&connect_flights){
    int arrive_time=convert_time_to_int2(first_flight->get_arrival_time());
    int dep_time=convert_time_to_int2(second_flight->get_departure_time());
    int duration=dep_time-arrive_time;
    if(duration>=0 && duration<=900){
        Connecting_Flight * new_cnt_flight=new Connecting_Flight(first_flight,second_flight,duration);
        connect_flights.push_back(new_cnt_flight);
    }   
}

void Utravel :: check_diffday_connect(Flight * first_flight,Flight * second_flight,vector<Connecting_Flight*>&connect_flights){
    int arrive_time=1440-convert_time_to_int2(first_flight->get_arrival_time());
    int dep_time=convert_time_to_int2(second_flight->get_departure_time());
    int duration=dep_time+arrive_time;
    if(duration>=0 && duration<=900){
        Connecting_Flight * new_cnt_flight=new Connecting_Flight(first_flight,second_flight,duration);
        connect_flights.push_back(new_cnt_flight);
    }
}
void Utravel::check_connectibility(Flight * first_flight,Flight * second_flight,vector<Connecting_Flight*>&connect_flights){
    if(first_flight->get_arrival_date()==second_flight->get_departure_date()){
        check_sameday_connect(first_flight,second_flight,connect_flights);
    }
    else if(stoi(first_flight->get_arrival_date())+1 == stoi(second_flight->get_departure_date())){
        check_diffday_connect(first_flight,second_flight,connect_flights);
    }
}

vector<Connecting_Flight*> Utravel :: connect_if_ok(vector<Flight*>first_flights,vector<Flight *>second_flights){
    vector<Connecting_Flight *>connect_flights;
    for(int i=0;i<first_flights.size();i++){
        for(int j=0;j<second_flights.size();j++){
            if(first_flights[i]->get_destination()==second_flights[j]->get_origin()){
                check_connectibility(first_flights[i],second_flights[j],connect_flights);
            }
        }
    }
    return connect_flights;
}
vector<Connecting_Flight*>  Utravel :: collect_flights_for_connect(vector<string>command,int from_index,int to_index,int date_index){
    vector< Flight * > first_flights,second_flights,first_flights_edit;
    vector<Connecting_Flight *>connect_flights;
    for(int i=0;i<flights.size();i++){
        if(flights[i]->get_origin()==command[from_index])
            first_flights.push_back(flights[i]);           
        if(flights[i]->get_destination()==command[to_index])
            second_flights.push_back(flights[i]);
    }
    if(date_index!=0){
        for(int j=0;j<first_flights.size();j++){
            if(first_flights[j]->get_departure_date()==command[date_index])
                first_flights_edit.push_back(first_flights[j]);
        }
    }
    else
        first_flights_edit=first_flights;
    connect_flights=connect_if_ok(first_flights_edit,second_flights);
    return connect_flights;   
}
void Utravel:: print_connect_flights(vector< Connecting_Flight *>connect_flights){
    for(int i=0;i<connect_flights.size();i++){
        connect_flights[i]->print();
        cout<<DASH_SEP<<endl;
    }
}
void Utravel :: sort_connect_flights(vector< Connecting_Flight *>&connect_flights){
    Connecting_Flight * temp;
    for(int i=0;i<connect_flights.size();i++){
        for(int j=1;j<connect_flights.size();j++){
            if(connect_flights[j-1]->get_cost() > connect_flights[j]->get_cost()){
                temp=connect_flights[j-1];
                connect_flights[j-1]=connect_flights[j];
                connect_flights[j]=temp;
            }
        }
    }
}
void Utravel:: find_connecting_flight(vector<string>command){
    if(command.size()!=7)
        throw(INVALID_COMMAND_FORM);
    if(signed_status ==0)
        throw(PER_DENY);
    int from_index=find_argument(command,FROM);
    int to_index=find_argument(command,TO);
    if(from_index != ERR && to_index != ERR){
        vector<Connecting_Flight *> connect_flights=collect_flights_for_connect(command,from_index+1,to_index+1,0);
        if(connect_flights.size()==0)
            throw(NON_ACCEPTABLE_COMMAND);
        else{
            sort_connect_flights(connect_flights);
            print_connect_flights(connect_flights);
        }
    }
    else
        throw(INVALID_COMMAND_FORM);
}
vector<Flight*> Utravel:: find_matching_flights(vector<string>command,int from_index,int to_index,int date_index){
    vector<Flight *>matching_flights;
    int okay_check;
    for(int i=0;i<flights.size();i++){
        okay_check=0;
        if(command[from_index]==flights[i]->get_origin())
            okay_check+=1;
        if(command[to_index]==flights[i]->get_destination())
            okay_check+=1;
        if(command[date_index]==flights[i]->get_departure_date())
            okay_check+=1;
        if(okay_check==3)
            matching_flights.push_back(flights[i]);
    }
    return matching_flights;
}
int Utravel:: find_cheapest_index(vector<Flight*>wanted_flights){
    int index=0;
    if(wanted_flights.size()==0)
        return ERR;
    for(int i=1;i<wanted_flights.size();i++){
        if(wanted_flights[i]->get_cost()<wanted_flights[index]->get_cost())
            index=i;
    }
    return index;
}
int Utravel:: find_cheapest_connecting_index(vector<Connecting_Flight*>wanted_flights){
    int index=0;
    if(wanted_flights.size()==0)
        return ERR;    
    for(int i=1;i<wanted_flights.size();i++){
        if(wanted_flights[i]->get_cost()<wanted_flights[index]->get_cost())
            index=i;
    }
    return index;
}

void Utravel :: find_cheapest_straight(vector<Flight*>wanted_flights){
    int min_index=find_cheapest_index(wanted_flights);
    wanted_flights[min_index]->print_flight_info();
    cout<<TOT_COST<<": "<<((float)((int)(wanted_flights[min_index]->get_cost()*100)))/100.0<<endl;
}

void Utravel :: find_cheapest_connecting(vector<Connecting_Flight*>wanted_connecting_flights){
    int min_index_connecting=find_cheapest_connecting_index(wanted_connecting_flights);
    wanted_connecting_flights[min_index_connecting]->get_first_flight()->print_flight_info();
    wanted_connecting_flights[min_index_connecting]->get_second_flight()->print_flight_info();
    float total_price=wanted_connecting_flights[min_index_connecting]->get_first_flight()->get_cost()+
    wanted_connecting_flights[min_index_connecting]->get_second_flight()->get_cost();
    cout<<TOT_COST<<": "<<((float)((int)(total_price*100)))/100.0<<endl;
}

void Utravel :: find_cheapest_both(vector<Flight*>wanted_flights,vector<Connecting_Flight*>wanted_connecting_flights){
    int min_index=find_cheapest_index(wanted_flights);
    int min_index_connecting=find_cheapest_connecting_index(wanted_connecting_flights);
    if(wanted_flights[min_index]->get_cost() <= wanted_connecting_flights[min_index_connecting]->get_cost()){
        wanted_flights[min_index]->print_flight_info();
        wanted_flights[min_index]->print_flight_info();
        cout<<TOT_COST<<": "<<((float)((int)(wanted_flights[min_index]->get_cost()*100)))/100.0<<endl;
    }
    else{
        wanted_connecting_flights[min_index_connecting]->get_first_flight()->print_flight_info();
        wanted_connecting_flights[min_index_connecting]->get_second_flight()->print_flight_info();
        float total_price=wanted_connecting_flights[min_index_connecting]->get_first_flight()->get_cost()+
        wanted_connecting_flights[min_index_connecting]->get_second_flight()->get_cost();
        cout<<TOT_COST<<": "<<((float)((int)(wanted_flights[min_index]->get_cost()*100)))/100.0<<endl;
    }
}
void Utravel ::find_cheapest(vector<string>command){
    if(signed_status==0)
        throw(PER_DENY);
    if(command.size()!=9)
        throw(INVALID_COMMAND_FORM);
    int from_index=find_argument(command,FROM);
    int to_index=find_argument(command,TO);
    int date_index=find_argument(command,DEP_DATE);
    if(from_index !=ERR && to_index!=ERR && date_index!=ERR){
        vector<Flight*>wanted_flights=find_matching_flights(command,from_index+1,to_index+1,date_index+1);
        vector<Connecting_Flight*>wanted_connecting_flights=collect_flights_for_connect(command,from_index+1,to_index+1,date_index+1);
        if(wanted_connecting_flights.size()==0 && wanted_flights.size()==0)
            throw(NON_ACCEPTABLE_COMMAND);
        else if(wanted_connecting_flights.size()==0 && wanted_flights.size()!=0)
            find_cheapest_straight(wanted_flights);
        else if(wanted_connecting_flights.size()!=0 && wanted_flights.size()==0)
            find_cheapest_connecting(wanted_connecting_flights);
        else
            find_cheapest_both(wanted_flights,wanted_connecting_flights);
    }
    else
        throw(INVALID_COMMAND_FORM);
}