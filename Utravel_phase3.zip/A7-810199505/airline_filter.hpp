#ifndef _AIRLINE_HPP_
#define _AIRLINE_HPP_

#include<iostream>
#include<string>

using namespace std;

class Airline_filter {
    public:
        Airline_filter();
        void apply_filter(string Airline_name,vector<Flight*>flights);
        
    private:
        string airline;
};

#endif