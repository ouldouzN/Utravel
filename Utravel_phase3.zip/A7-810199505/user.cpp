#include"user.hpp"
#include"exception.hpp"
#include<sstream>
#include<iostream>
#include<string>
#define ERR -1

const string INVALID_COMMAND_FORM="Bad request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string BUSINESS="business";
const string ECO="economy";
const string REF="refundable";
const string NON_REF="nonrefundable";

User :: User(string name,string pass){
    username=name;
    password=pass;
    wallet_money=0;
}

string User:: get_username(){
    return username;
}

void User:: charge_wallet(float amount){
    if(amount<0)
        throw Bad_request();
    else{
        wallet_money+=amount;
    }

}

bool check_seat_ok(Ticket * new_tick){
    Flight * this_flight=new_tick->get_flight();
    if(new_tick->get_class()==BUSINESS){
        if(this_flight->get_business_seats() <= new_tick->get_quantity())
            return false;
    }
    else{
        if(this_flight->get_economy_seats() <= new_tick->get_quantity()){            
            return false;
        }
    }
    return true;
}

void User :: calculate_left_money(Ticket *new_tick){
    wallet_money -=new_tick->get_cost();
}

void User :: change_seats(Ticket * new_tick){
    Flight * this_flight=new_tick->get_flight();
    if(new_tick->get_class()==BUSINESS)
        this_flight->change_business_seat_num((new_tick->get_quantity())*(-1));
    else
        this_flight->change_economy_seat_num((new_tick->get_quantity())*(-1));
}

void User ::buy_ticket(int id,Flight* tick_flight,int quantity,string tick_class,string tick_type){
    Ticket * new_tick=new Ticket(id,tick_flight,quantity,tick_class,tick_type);
    calculate_left_money(new_tick);
    change_seats(new_tick);
    new_tick->set_id(id+1);
    tickets.push_back(new_tick);
}

string User:: print_this_ticket(int i){
    int index=find_ticket(i);
    ostringstream body;    
    body<<"<tr>";
    body<<tickets[index]->print_full_info();
    return body.str();

}

string  User:: print_tickets(){
    ostringstream body;
    body<<"<tr>";
    for(int i=0;i<tickets.size();i++){
        body<<tickets[i]->print();
    }
    return body.str();
}

int User:: find_ticket(int id){
    for(int i=0;i<tickets.size();i++){
        if(tickets[i]->get_id()==id)
            return i;
    }
    return ERR;
}

string User:: cancel_a_ticket(int id){
    int the_ticket=find_ticket(id);
    if(tickets[the_ticket]->get_type()==NON_REF){
        throw Bad_request();
    }
    else{
        Flight * this_tick_flight=tickets[the_ticket]->get_flight();
        if(tickets[the_ticket]->get_class()==BUSINESS){
            this_tick_flight->change_business_seat_num(tickets[the_ticket]->get_quantity());
            wallet_money+=(0.5)*tickets[the_ticket]->get_cost();
        }    
        if(tickets[the_ticket]->get_class()==ECO){
            this_tick_flight->change_economy_seat_num(tickets[the_ticket]->get_quantity());
            wallet_money+=(0.5)*tickets[the_ticket]->get_cost();
        }    
        tickets.erase(tickets.begin()+the_ticket);
        return acceptable_command;
    }
}

string User:: get_password(){
    return password;
}

Ticket * User :: get_ticket(int id){
    for(int i=0;i<tickets.size();i++){
        if(tickets[i]->get_id()==id)
            return tickets[i];
    }
    return NULL;
}

float User :: get_wallet_money(){
    return wallet_money;
}