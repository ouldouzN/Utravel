#ifndef EXC_HPP
#define EXC_HPP

#include<exception>
#include <iostream>
#include <string>

using namespace std;

class Bad_request : public exception{
public:
	const char* what() const noexcept{ return "Bad Request\n";}
private:
};

class Not_found : public exception{
public:
	const char* what() const noexcept{ return "Not Found\n";}
private:

};

class Permission_denied : public exception{
public:
	const char* what() const noexcept{ return "Permission Denied\n";}
private:
};

class Wrong_format : public exception
{
public:
	const char* what() const noexcept{ return "Wrong Format\n";}
private:
};
#endif