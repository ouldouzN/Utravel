#include"filter.hpp"
#include"cost_filter.hpp"
#define APPLIED 1
#define UNAPPLIED 0

const string INVALID_COMMAND_FORM="Bad Request";
const string acceptable_command="OK";
const string NON_ACCEPTABLE_COMMAND="Not Found";
const string PER_DENY="Permission Denied";
const string EMP="Empty";
const string MIN_PRC="min_price";
const string MAX_PRC="max_price";

Cost_filter::Cost_filter(){
}


void Cost_filter :: apllying_min_price(string min_price,vector<Flight*>flights){
    if(stof(min_price)<0)
        throw Bad_request();
    for(int j=0;j<flights.size();j++){
        flights[j]->set_cost_ok(1);
    }
    for(int i=0;i<flights.size();i++){
        if(flights[i]->get_cost()<stof(min_price)){
            flights[i]->set_cost_ok(UNAPPLIED);
        }
    }
}

void Cost_filter :: apllying_max_price(string max_price,vector<Flight*>flights){
    if(stof(max_price)<0)
        throw Bad_request();
    for(int j=0;j<flights.size();j++){
        flights[j]->set_cost_ok(1);
    }
    for(int i=0;i<flights.size();i++){
        if(flights[i]->get_cost()>stof(max_price)){
            flights[i]->set_cost_ok(UNAPPLIED);
        }
    }
}

void Cost_filter :: apllying_min_and_max_price(string min_price,string max_price,vector<Flight*>flights){
    if(stof(min_price)< 0 || stof(max_price)<stof(min_price))
        throw Bad_request();
    for(int j=0;j<flights.size();j++){
        flights[j]->set_cost_ok(1);
    }
    for(int i=0;i<flights.size();i++){
        if(flights[i]->get_cost()< stof(min_price) || flights[i]->get_cost()>stof(max_price)){
            flights[i]->set_cost_ok(UNAPPLIED);
        }
    }
}


void  Cost_filter ::apply_filter(string min_price,string max_price,vector<Flight*>flights){
    if(min_price=="" && max_price!=""){
        apllying_max_price(max_price,flights);
    }
    else if(min_price!="" && max_price==""){
        apllying_min_price(min_price,flights);       
    }
    else if(min_price!="" && max_price!=""){
        apllying_min_and_max_price(min_price,max_price,flights);
    }
    else
        throw Bad_request();
}